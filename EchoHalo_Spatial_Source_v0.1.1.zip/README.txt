EchoHalo Spatial Calibration Lab v0.4.0

Experimental native Android companion for EchoHalo.
Learns LEFT / FRONT / RIGHT / BEHIND acoustic fingerprints from Samsung's public 48 kHz stereo CAMCORDER stream, then performs live nearest-profile direction classification.

See README_GITHUB_BUILD.md for test instructions.
