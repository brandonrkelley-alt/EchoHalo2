EchoHalo Third Mic Hunter v0.2.0

Purpose:
- Determine whether Samsung's factory-test SPK_3rdMic hardware path can be exposed to an ordinary Android app through documented public APIs.
- Enumerate public microphones and input devices.
- Force preferred input routing through each public candidate device.
- Test DEFAULT, MIC, CAMCORDER, UNPROCESSED, VOICE_RECOGNITION, VOICE_COMMUNICATION, and VOICE_PERFORMANCE audio sources.
- Test Android microphone direction hints (towards user, away from user, external) and field-dimension/zoom hints.
- Flag any new active microphone ID that appears outside the normal bottom/back inventory.

No Samsung factory service, hidden binder API, root command, or firmware setting is invoked.
