ECHOHALO SPATIAL PROBE v0.1.0
==============================

Purpose
-------
This is the native Android hardware probe for EchoHalo. It does not replace the EchoHalo PWA.
It asks Android for information the browser cannot expose:

- Physical microphones reported by AudioManager.getMicrophones()
- Microphone position and orientation metadata
- Active microphones for each AudioRecord capture
- DIRECT vs PROCESSED channel mappings
- 1, 2, 3, and 4-channel capture attempts
- DEFAULT, UNPROCESSED, VOICE_RECOGNITION, and CAMCORDER sources
- Per-channel RMS energy
- Pairwise channel correlation and sample lag when multichannel capture works

The app declares RECORD_AUDIO and INTERNET only. It does not alter cochlear-implant settings.

Build in Android Studio
-----------------------
1. Open this folder as an Android Studio project.
2. Let Gradle sync/install Android SDK 35 if Android Studio requests it.
3. Connect an Android phone with USB debugging or choose Build > Build APK(s).
4. Install app-debug.apk on the phone.
5. Open EchoHalo Spatial Probe and tap Run Spatial Probe.
6. Allow microphone access.
7. Speak continuously and slowly rotate the phone while it runs.
8. Tap Copy Report or Share Report and send the text back to ChatGPT.

What we hope to see
-------------------
Best case:
- 2 or more capture channels
- 2 or more active physical microphone IDs
- MicrophoneInfo channel mappings marked DIRECT on distinct channels

That would justify a real GCC-PHAT / beamforming localization prototype.

If all native captures remain mono, or mappings are only PROCESSED, Samsung's audio HAL is combining
microphones before ordinary apps can access them. In that case an external multi-microphone array is
the reliable route for SpeechCompass-style direction.

EchoHalo PWA:
https://bk26.neocities.org/EchoHalo/
