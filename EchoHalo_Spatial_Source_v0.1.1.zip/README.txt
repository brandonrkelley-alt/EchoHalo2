EchoHalo Route Witness v0.3.1

Purpose
-------
This Android diagnostic observes public audio-routing metadata while Samsung Camera Pro Video switches between OMNI, FRONT, and REAR microphone modes.

The app does NOT record microphone audio in Route Witness mode. It runs a user-started foreground diagnostic service, monitors AudioManager recording configuration callbacks / input-device changes, and writes a local text report.

Test sequence
-------------
1. Start Route Witness.
2. Open Samsung Camera > More > Pro Video.
3. Select OMNI. Pull down notifications and tap MARK OMNI. Record 3-5 seconds while speaking, then stop.
4. Select FRONT. Tap MARK FRONT. Record 3-5 seconds, then stop.
5. Select REAR. Tap MARK REAR. Record 3-5 seconds, then stop.
6. Return to EchoHalo and tap Stop Witness & Load Report.
7. Copy/share the report back to ChatGPT.

What is logged
--------------
- AudioManager mode and communication device
- all public input devices
- AudioManager.getActiveRecordingConfigurations()
- client/effective audio source
- client and hardware AudioFormat
- active capture effects and client effects
- public microphone inventory
- selected read-only audio HAL parameter clues, when visible
- audio device add/remove callbacks
- user phase markers for OMNI / FRONT / REAR

Privacy
-------
The Route Witness itself does not instantiate AudioRecord and does not save or transmit audio. Android may anonymize metadata belonging to Samsung Camera, so lack of visible changes does not prove Samsung's private DSP route is unchanged.
