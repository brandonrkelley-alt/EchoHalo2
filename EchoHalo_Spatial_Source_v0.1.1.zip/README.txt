EchoHalo Spatial Calibration Lab v0.4.1

Experimental native Android companion for EchoHalo.

v0.4.1 preserves the v0.4.0 LEFT / FRONT / RIGHT / BEHIND calibration format and adds a blind repeatability test:
- live best direction + posterior
- runner-up direction + posterior
- confidence and centroid-distance detail
- live interchannel lag history with calibration-center guides
- ACTUAL direction buttons for ground-truth trials
- confusion matrix, total accuracy, and per-direction recall
- per-trial feature logging in COPY REPORT

The app still uses Samsung/Android's public 48 kHz stereo CAMCORDER AudioRecord stream. It does not alter cochlear-implant programming.

See README_GITHUB_BUILD.md for build and test instructions.
