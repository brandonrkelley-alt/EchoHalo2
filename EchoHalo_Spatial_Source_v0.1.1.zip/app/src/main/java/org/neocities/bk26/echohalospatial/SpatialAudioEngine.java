package org.neocities.bk26.echohalospatial;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.AudioDeviceInfo;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Handler;
import android.os.Looper;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class SpatialAudioEngine {
    public enum Direction {
        LEFT("LEFT", "←"), FRONT("FRONT", "↑"), RIGHT("RIGHT", "→"), BEHIND("BEHIND", "↓");
        public final String label;
        public final String arrow;
        Direction(String label, String arrow) { this.label = label; this.arrow = arrow; }
    }

    public interface Listener {
        void onEngineStatus(String text, boolean error);
        void onFeature(Feature f);
        void onCalibrationProgress(Direction d, long millisRemaining, int acceptedFrames);
        void onCalibrationComplete(Direction d, CalibrationProfile p);
        void onClassification(ClassificationResult result);
    }

    public static final int SAMPLE_RATE = 48000;
    private static final int FRAME_SAMPLES = 1024;
    private static final int FRAME_SHORTS = FRAME_SAMPLES * 2;
    private static final long CALIBRATION_MS = 4500;
    private static final int MIN_CALIBRATION_FRAMES = 45;
    private static final double ACTIVE_RMS_DB = -52.0;
    private static final double[] FLOOR_SCALE = {3.5, 2.5, 2.5, 2.5, 0.10};
    private static final long MAX_TRUTH_AGE_NS = 1_500_000_000L;

    private final Context context;
    private final Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Map<Direction, CalibrationProfile> profiles = new EnumMap<>(Direction.class);
    private final Object stateLock = new Object();
    private final Object blindLock = new Object();
    private final ArrayDeque<double[]> smoothedPosteriors = new ArrayDeque<>();
    private final StringBuilder sessionLog = new StringBuilder();
    private final int[][] confusion = new int[Direction.values().length][Direction.values().length];
    private final List<BlindTrial> blindTrials = new ArrayList<>();

    private volatile boolean running = false;
    private volatile boolean liveEnabled = false;
    private Thread audioThread;
    private AudioRecord record;
    private Direction calibrationTarget;
    private long calibrationEndNanos;
    private final List<Feature> calibrationFrames = new ArrayList<>();
    private volatile Feature latestFeature;
    private volatile ClassificationResult latestClassification;
    private long lastRecordedClassificationNanos = Long.MIN_VALUE;
    private String routeSummary = "not started";

    public SpatialAudioEngine(Context context, Listener listener) {
        this.context = context.getApplicationContext();
        this.listener = listener;
        loadProfiles();
    }

    public boolean isRunning() { return running; }
    public boolean isLiveEnabled() { return liveEnabled; }
    public boolean hasAllProfiles() { return profiles.size() == Direction.values().length; }
    public int profileCount() { return profiles.size(); }
    public CalibrationProfile getProfile(Direction d) { return profiles.get(d); }
    public Feature getLatestFeature() { return latestFeature; }
    public ClassificationResult getLatestClassification() { return latestClassification; }

    public void setLiveEnabled(boolean enabled) {
        liveEnabled = enabled;
        latestClassification = null;
        synchronized (smoothedPosteriors) { smoothedPosteriors.clear(); }
        log("LIVE " + (enabled ? "ON" : "OFF"));
    }

    public void start() {
        if (running) return;
        running = true;
        audioThread = new Thread(this::audioLoop, "EchoHaloSpatialAudio");
        audioThread.start();
    }

    public void stop() {
        running = false;
        liveEnabled = false;
        latestClassification = null;
        synchronized (stateLock) {
            calibrationTarget = null;
            calibrationFrames.clear();
        }
        AudioRecord r = record;
        if (r != null) {
            try { r.stop(); } catch (Exception ignored) {}
        }
    }

    public void beginCalibration(Direction d) {
        if (!running) {
            postStatus("Start the microphone before calibrating.", true);
            return;
        }
        if (getBlindTrialCount() > 0) clearBlindTrials();
        synchronized (stateLock) {
            calibrationTarget = d;
            calibrationFrames.clear();
            calibrationEndNanos = System.nanoTime() + CALIBRATION_MS * 1_000_000L;
        }
        setLiveEnabled(false);
        log("CAL START " + d.label);
    }

    public void clearCalibration() {
        profiles.clear();
        SharedPreferences.Editor e = prefs().edit().clear();
        e.apply();
        synchronized (smoothedPosteriors) { smoothedPosteriors.clear(); }
        latestClassification = null;
        log("CALIBRATION CLEARED");
    }

    public BlindTrial recordGroundTruth(Direction actual) {
        ClassificationResult r = latestClassification;
        long now = System.nanoTime();
        if (!liveEnabled || r == null || !r.accepted || r.best == null) return null;
        if (now - r.timestampNanos > MAX_TRUTH_AGE_NS) return null;
        synchronized (blindLock) {
            if (r.timestampNanos == lastRecordedClassificationNanos) return null;
            lastRecordedClassificationNanos = r.timestampNanos;
            BlindTrial trial = new BlindTrial(blindTrials.size() + 1, actual, r, now);
            blindTrials.add(trial);
            confusion[actual.ordinal()][r.best.ordinal()]++;
            log(String.format(Locale.US,
                    "TRIAL #%d actual=%s predicted=%s posterior=%.1f%% runner=%s %.1f%% confidence=%.1f%% lag=%+.1f",
                    trial.number, actual.label, r.best.label, r.bestPosterior * 100.0,
                    r.runnerUp == null ? "-" : r.runnerUp.label, r.runnerUpPosterior * 100.0,
                    r.confidence * 100.0, r.feature.lagSamples));
            return trial;
        }
    }

    public void clearBlindTrials() {
        synchronized (blindLock) {
            for (int i = 0; i < confusion.length; i++) {
                for (int j = 0; j < confusion[i].length; j++) confusion[i][j] = 0;
            }
            blindTrials.clear();
            lastRecordedClassificationNanos = Long.MIN_VALUE;
        }
        log("BLIND TRIALS CLEARED");
    }

    public int getBlindTrialCount() {
        synchronized (blindLock) { return blindTrials.size(); }
    }

    public int getBlindCorrectCount() {
        synchronized (blindLock) {
            int n = 0;
            for (int i = 0; i < confusion.length; i++) n += confusion[i][i];
            return n;
        }
    }

    public int[][] getConfusionMatrixCopy() {
        synchronized (blindLock) {
            int[][] out = new int[confusion.length][confusion.length];
            for (int i = 0; i < confusion.length; i++) {
                System.arraycopy(confusion[i], 0, out[i], 0, confusion[i].length);
            }
            return out;
        }
    }

    private void audioLoop() {
        try {
            int minBytes = AudioRecord.getMinBufferSize(SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT);
            int bufferBytes = Math.max(minBytes * 2, FRAME_SHORTS * 2 * 4);
            AudioFormat format = new AudioFormat.Builder()
                    .setSampleRate(SAMPLE_RATE)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                    .build();
            record = new AudioRecord.Builder()
                    .setAudioSource(MediaRecorder.AudioSource.CAMCORDER)
                    .setAudioFormat(format)
                    .setBufferSizeInBytes(bufferBytes)
                    .build();

            if (record.getState() != AudioRecord.STATE_INITIALIZED) {
                throw new IllegalStateException("AudioRecord did not initialize");
            }
            record.startRecording();
            if (record.getRecordingState() != AudioRecord.RECORDSTATE_RECORDING) {
                throw new IllegalStateException("AudioRecord did not enter RECORDING state");
            }

            AudioDeviceInfo routed = null;
            try { routed = record.getRoutedDevice(); } catch (Throwable ignored) {}
            routeSummary = "source=CAMCORDER  rate=" + record.getSampleRate() + " Hz  channels=" +
                    record.getChannelCount() + "  routed=" + deviceText(routed);
            log("ENGINE START " + routeSummary);
            if (record.getChannelCount() < 2) {
                postStatus("Android collapsed CAMCORDER to mono. This build needs two delivered channels.", true);
                running = false;
                return;
            }
            postStatus("Spatial stream active · " + routeSummary, false);

            short[] data = new short[FRAME_SHORTS];
            while (running) {
                int n = record.read(data, 0, data.length, AudioRecord.READ_BLOCKING);
                if (n <= 0) continue;
                if (n < FRAME_SHORTS) continue;
                Feature f = FeatureExtractor.extract(data, FRAME_SAMPLES, SAMPLE_RATE);
                latestFeature = f;
                main.post(() -> listener.onFeature(f));
                handleCalibrationAndClassification(f);
            }
        } catch (SecurityException se) {
            postStatus("Microphone permission is required: " + se.getMessage(), true);
        } catch (Throwable t) {
            postStatus("Audio engine error: " + t.getClass().getSimpleName() + ": " + safe(t.getMessage()), true);
            log("ENGINE ERROR " + t);
        } finally {
            AudioRecord r = record;
            record = null;
            if (r != null) {
                try { r.stop(); } catch (Exception ignored) {}
                try { r.release(); } catch (Exception ignored) {}
            }
            running = false;
            log("ENGINE STOP");
        }
    }

    private void handleCalibrationAndClassification(Feature f) {
        Direction target;
        long remainMs;
        int count;
        boolean finish = false;
        synchronized (stateLock) {
            target = calibrationTarget;
            if (target != null) {
                if (f.rmsDb > ACTIVE_RMS_DB && f.peakCorr > 0.05) calibrationFrames.add(f);
                remainMs = Math.max(0, (calibrationEndNanos - System.nanoTime()) / 1_000_000L);
                count = calibrationFrames.size();
                if (remainMs <= 0) finish = true;
            } else {
                remainMs = 0;
                count = 0;
            }
        }

        if (target != null) {
            final Direction td = target;
            final long rr = remainMs;
            final int cc = count;
            main.post(() -> listener.onCalibrationProgress(td, rr, cc));
            if (finish) finishCalibration(target);
            return;
        }

        if (liveEnabled && hasAllProfiles()) classify(f);
    }

    private void finishCalibration(Direction d) {
        List<Feature> frames;
        synchronized (stateLock) {
            if (calibrationTarget != d) return;
            frames = new ArrayList<>(calibrationFrames);
            calibrationTarget = null;
            calibrationFrames.clear();
        }
        if (frames.size() < MIN_CALIBRATION_FRAMES) {
            postStatus("Calibration " + d.label + " failed: only " + frames.size() +
                    " usable frames. Turn the external calibration noise up slightly and retry.", true);
            log("CAL FAIL " + d.label + " frames=" + frames.size());
            return;
        }
        CalibrationProfile p = CalibrationProfile.fromFrames(d, frames);
        profiles.put(d, p);
        saveProfile(p);
        log("CAL DONE " + p.reportLine());
        main.post(() -> listener.onCalibrationComplete(d, p));
    }

    private void classify(Feature f) {
        if (f.rmsDb < ACTIVE_RMS_DB || f.peakCorr < 0.04) {
            ClassificationResult result = ClassificationResult.rejected(f, "waiting for a clear sound");
            latestClassification = result;
            main.post(() -> listener.onClassification(result));
            return;
        }
        Direction[] dirs = Direction.values();
        double[] raw = new double[dirs.length];
        double[] distances = new double[dirs.length];
        double sum = 0;
        StringBuilder detail = new StringBuilder();
        for (int i = 0; i < dirs.length; i++) {
            CalibrationProfile p = profiles.get(dirs[i]);
            double d2 = distanceSquared(f.vector(), p);
            distances[i] = Math.sqrt(d2);
            raw[i] = Math.exp(-0.5 * Math.min(40.0, d2));
            sum += raw[i];
            if (i > 0) detail.append("  ");
            detail.append(dirs[i].label.charAt(0)).append('=')
                    .append(String.format(Locale.US, "%.2f", distances[i]));
        }
        if (sum <= 1e-12) {
            ClassificationResult result = ClassificationResult.rejected(f, "outside calibration envelope");
            latestClassification = result;
            main.post(() -> listener.onClassification(result));
            return;
        }
        for (int i = 0; i < raw.length; i++) raw[i] /= sum;

        double[] avg = new double[raw.length];
        synchronized (smoothedPosteriors) {
            smoothedPosteriors.addLast(raw.clone());
            while (smoothedPosteriors.size() > 9) smoothedPosteriors.removeFirst();
            for (double[] q : smoothedPosteriors) {
                for (int i = 0; i < avg.length; i++) avg[i] += q[i];
            }
            for (int i = 0; i < avg.length; i++) avg[i] /= smoothedPosteriors.size();
        }
        int best = 0;
        for (int i = 1; i < avg.length; i++) if (avg[i] > avg[best]) best = i;
        int second = best == 0 ? 1 : 0;
        for (int i = 0; i < avg.length; i++) if (i != best && avg[i] > avg[second]) second = i;
        double separation = Math.max(0, avg[best] - avg[second]);
        double confidence = Math.max(0, Math.min(1, avg[best] * 0.75 + separation * 0.55));
        Direction answer = dirs[best];
        Direction runner = dirs[second];
        String dtext = detail.toString();
        ClassificationResult result = new ClassificationResult(
                true, answer, runner, avg[best], avg[second], confidence,
                avg.clone(), distances, f, dtext, System.nanoTime());
        latestClassification = result;
        main.post(() -> listener.onClassification(result));
    }

    private double distanceSquared(double[] x, CalibrationProfile p) {
        double sum = 0;
        for (int i = 0; i < x.length; i++) {
            double spread = Math.max(FLOOR_SCALE[i], p.robustSigma[i]);
            double z = (x[i] - p.center[i]) / spread;
            sum += z * z;
        }
        return sum;
    }

    private void postStatus(String text, boolean error) {
        main.post(() -> listener.onEngineStatus(text, error));
    }

    private void saveProfile(CalibrationProfile p) {
        SharedPreferences.Editor e = prefs().edit();
        e.putString("center_" + p.direction.name(), join(p.center));
        e.putString("sigma_" + p.direction.name(), join(p.robustSigma));
        e.putInt("count_" + p.direction.name(), p.frames);
        e.apply();
    }

    private void loadProfiles() {
        SharedPreferences sp = prefs();
        for (Direction d : Direction.values()) {
            String c = sp.getString("center_" + d.name(), null);
            String s = sp.getString("sigma_" + d.name(), null);
            if (c == null || s == null) continue;
            try {
                double[] center = parse(c);
                double[] sigma = parse(s);
                if (center.length == 5 && sigma.length == 5) {
                    profiles.put(d, new CalibrationProfile(d, center, sigma,
                            sp.getInt("count_" + d.name(), 0)));
                }
            } catch (Exception ignored) {}
        }
    }

    private SharedPreferences prefs() {
        return context.getSharedPreferences("echohalo_spatial_calibration_v1", Context.MODE_PRIVATE);
    }

    private String join(double[] a) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < a.length; i++) {
            if (i > 0) b.append(',');
            b.append(String.format(Locale.US, "%.8f", a[i]));
        }
        return b.toString();
    }

    private double[] parse(String s) {
        String[] p = s.split(",");
        double[] out = new double[p.length];
        for (int i = 0; i < p.length; i++) out[i] = Double.parseDouble(p[i]);
        return out;
    }

    public String buildReport() {
        StringBuilder b = new StringBuilder();
        b.append("EchoHalo Spatial Calibration Lab v0.4.1\n");
        b.append("Device route: ").append(routeSummary).append("\n");
        b.append("Sample rate: ").append(SAMPLE_RATE).append(" Hz\n");
        b.append("Classifier features: GCC-style interchannel lag + low/mid/high interchannel level difference + peak correlation\n");
        b.append("Classifier smoothing: 9 accepted-frame posterior moving average\n");
        b.append("Blind truth rule: latest accepted classification must be <1.5 s old; one ground-truth tap = one trial\n");
        b.append("Orientation: phone flat, screen up; top edge=FRONT, right edge=RIGHT, bottom edge=BEHIND, left edge=LEFT\n\n");
        b.append("CALIBRATION PROFILES\n");
        for (Direction d : Direction.values()) {
            CalibrationProfile p = profiles.get(d);
            b.append("  ").append(d.label).append(": ");
            if (p == null) b.append("<not calibrated>\n");
            else b.append(p.reportLine()).append('\n');
        }
        Feature f = latestFeature;
        if (f != null) {
            b.append("\nLATEST FEATURE\n  ").append(f.reportLine()).append('\n');
        }
        ClassificationResult cr = latestClassification;
        if (cr != null && cr.accepted) {
            b.append("\nLATEST CLASSIFICATION\n  ").append(cr.reportLine()).append('\n');
        }
        appendBlindReport(b);
        b.append("\nSESSION LOG\n").append(sessionLog);
        return b.toString();
    }

    private void appendBlindReport(StringBuilder b) {
        synchronized (blindLock) {
            int total = blindTrials.size();
            int correct = 0;
            for (int i = 0; i < confusion.length; i++) correct += confusion[i][i];
            b.append("\nBLIND REPEATABILITY TEST\n");
            b.append("  Trials: ").append(total).append("  Correct: ").append(correct);
            if (total > 0) b.append(String.format(Locale.US, "  Accuracy: %.1f%%", correct * 100.0 / total));
            b.append('\n');
            b.append("  Confusion matrix (rows=ACTUAL, columns=PREDICTED)\n");
            b.append("             LEFT FRONT RIGHT BEHIND\n");
            for (Direction actual : Direction.values()) {
                b.append(String.format(Locale.US, "  %-7s", actual.label));
                for (Direction predicted : Direction.values()) {
                    b.append(String.format(Locale.US, " %5d", confusion[actual.ordinal()][predicted.ordinal()]));
                }
                b.append('\n');
            }
            b.append("  Per-direction recall\n");
            for (Direction actual : Direction.values()) {
                int row = 0;
                for (int j = 0; j < confusion.length; j++) row += confusion[actual.ordinal()][j];
                b.append("    ").append(String.format(Locale.US, "%-7s", actual.label)).append("  ");
                if (row == 0) b.append("—\n");
                else b.append(String.format(Locale.US, "%d/%d = %.1f%%\n",
                        confusion[actual.ordinal()][actual.ordinal()], row,
                        confusion[actual.ordinal()][actual.ordinal()] * 100.0 / row));
            }
            if (!blindTrials.isEmpty()) {
                b.append("  Trials\n");
                for (BlindTrial t : blindTrials) b.append("    ").append(t.reportLine()).append('\n');
            }
        }
    }

    private synchronized void log(String s) {
        sessionLog.append(String.format(Locale.US, "%8.3fs  %s\n", System.nanoTime() / 1e9, s));
        if (sessionLog.length() > 36000) sessionLog.delete(0, 12000);
    }

    private String deviceText(AudioDeviceInfo d) {
        if (d == null) return "<hidden/null>";
        return "id=" + d.getId() + "/type=" + d.getType() + "/addr=" + safe(d.getAddress());
    }

    private static String safe(String s) { return s == null ? "" : s; }

    public static class ClassificationResult {
        public final boolean accepted;
        public final Direction best;
        public final Direction runnerUp;
        public final double bestPosterior;
        public final double runnerUpPosterior;
        public final double confidence;
        public final double[] posterior;
        public final double[] distances;
        public final Feature feature;
        public final String detail;
        public final long timestampNanos;

        ClassificationResult(boolean accepted, Direction best, Direction runnerUp,
                             double bestPosterior, double runnerUpPosterior, double confidence,
                             double[] posterior, double[] distances, Feature feature,
                             String detail, long timestampNanos) {
            this.accepted = accepted;
            this.best = best;
            this.runnerUp = runnerUp;
            this.bestPosterior = bestPosterior;
            this.runnerUpPosterior = runnerUpPosterior;
            this.confidence = confidence;
            this.posterior = posterior;
            this.distances = distances;
            this.feature = feature;
            this.detail = detail;
            this.timestampNanos = timestampNanos;
        }

        static ClassificationResult rejected(Feature f, String reason) {
            return new ClassificationResult(false, null, null, 0, 0, 0,
                    null, null, f, reason, System.nanoTime());
        }

        public String reportLine() {
            if (!accepted || best == null) return detail;
            return String.format(Locale.US,
                    "best=%s %.1f%%  runner=%s %.1f%%  confidence=%.1f%%  %s  distances[%s]",
                    best.label, bestPosterior * 100.0,
                    runnerUp == null ? "-" : runnerUp.label, runnerUpPosterior * 100.0,
                    confidence * 100.0, feature.reportLine(), detail);
        }
    }

    public static class BlindTrial {
        public final int number;
        public final Direction actual;
        public final Direction predicted;
        public final Direction runnerUp;
        public final double bestPosterior;
        public final double runnerUpPosterior;
        public final double confidence;
        public final Feature feature;
        public final long recordedNanos;

        BlindTrial(int number, Direction actual, ClassificationResult r, long recordedNanos) {
            this.number = number;
            this.actual = actual;
            this.predicted = r.best;
            this.runnerUp = r.runnerUp;
            this.bestPosterior = r.bestPosterior;
            this.runnerUpPosterior = r.runnerUpPosterior;
            this.confidence = r.confidence;
            this.feature = r.feature;
            this.recordedNanos = recordedNanos;
        }

        public boolean isCorrect() { return actual == predicted; }

        public String reportLine() {
            return String.format(Locale.US,
                    "#%03d actual=%-7s predicted=%-7s %s best=%.1f%% runner=%s %.1f%% confidence=%.1f%%  %s",
                    number, actual.label, predicted.label, isCorrect() ? "OK " : "MISS",
                    bestPosterior * 100.0,
                    runnerUp == null ? "-" : runnerUp.label, runnerUpPosterior * 100.0,
                    confidence * 100.0, feature.reportLine());
        }
    }

    public static class Feature {
        public final double lagSamples;
        public final double ildLow;
        public final double ildMid;
        public final double ildHigh;
        public final double peakCorr;
        public final double rmsDb;

        Feature(double lagSamples, double ildLow, double ildMid, double ildHigh,
                double peakCorr, double rmsDb) {
            this.lagSamples = lagSamples;
            this.ildLow = ildLow;
            this.ildMid = ildMid;
            this.ildHigh = ildHigh;
            this.peakCorr = peakCorr;
            this.rmsDb = rmsDb;
        }

        public double[] vector() { return new double[]{lagSamples, ildLow, ildMid, ildHigh, peakCorr}; }
        public String reportLine() {
            return String.format(Locale.US,
                    "lag=%+.1f samples (%+.3f ms)  ILD low=%+.2f dB mid=%+.2f dB high=%+.2f dB  corr=%.3f  rms=%.1f dBFS",
                    lagSamples, lagSamples / SAMPLE_RATE * 1000.0, ildLow, ildMid, ildHigh, peakCorr, rmsDb);
        }
    }

    public static class CalibrationProfile {
        public final Direction direction;
        public final double[] center;
        public final double[] robustSigma;
        public final int frames;

        CalibrationProfile(Direction direction, double[] center, double[] robustSigma, int frames) {
            this.direction = direction;
            this.center = center;
            this.robustSigma = robustSigma;
            this.frames = frames;
        }

        static CalibrationProfile fromFrames(Direction d, List<Feature> frames) {
            int dims = 5;
            double[] center = new double[dims];
            double[] sigma = new double[dims];
            for (int dim = 0; dim < dims; dim++) {
                List<Double> vals = new ArrayList<>();
                for (Feature f : frames) vals.add(f.vector()[dim]);
                Collections.sort(vals);
                center[dim] = median(vals);
                List<Double> dev = new ArrayList<>();
                for (double v : vals) dev.add(Math.abs(v - center[dim]));
                Collections.sort(dev);
                sigma[dim] = Math.max(1e-6, median(dev) * 1.4826);
            }
            return new CalibrationProfile(d, center, sigma, frames.size());
        }

        public String reportLine() {
            return String.format(Locale.US,
                    "frames=%d  center[lag=%+.2f low=%+.2f mid=%+.2f high=%+.2f corr=%.3f]  sigma[%.2f, %.2f, %.2f, %.2f, %.3f]",
                    frames, center[0], center[1], center[2], center[3], center[4],
                    robustSigma[0], robustSigma[1], robustSigma[2], robustSigma[3], robustSigma[4]);
        }

        private static double median(List<Double> x) {
            if (x.isEmpty()) return 0;
            int n = x.size();
            if ((n & 1) == 1) return x.get(n / 2);
            return (x.get(n / 2 - 1) + x.get(n / 2)) * 0.5;
        }
    }

    private static class FeatureExtractor {
        private static final int MAX_LAG = 32;

        static Feature extract(short[] interleaved, int frames, int sr) {
            int n = Math.min(frames, FRAME_SAMPLES);
            double[] l = new double[FRAME_SAMPLES];
            double[] r = new double[FRAME_SAMPLES];
            double sumSqL = 0, sumSqR = 0, meanL = 0, meanR = 0;
            for (int i = 0; i < n; i++) {
                l[i] = interleaved[i * 2] / 32768.0;
                r[i] = interleaved[i * 2 + 1] / 32768.0;
                meanL += l[i]; meanR += r[i];
                sumSqL += l[i] * l[i]; sumSqR += r[i] * r[i];
            }
            meanL /= n; meanR /= n;
            double rms = Math.sqrt((sumSqL + sumSqR) / (2.0 * n));
            double rmsDb = 20.0 * Math.log10(rms + 1e-12);

            double best = -1;
            int bestLag = 0;
            for (int lag = -MAX_LAG; lag <= MAX_LAG; lag++) {
                double num = 0, a = 0, b = 0;
                int start = Math.max(0, -lag);
                int end = Math.min(n, n - lag);
                for (int i = start; i < end; i++) {
                    double lv = l[i] - meanL;
                    double rv = r[i + lag] - meanR;
                    num += lv * rv;
                    a += lv * lv;
                    b += rv * rv;
                }
                double c = num / Math.sqrt(a * b + 1e-18);
                if (c > best) { best = c; bestLag = lag; }
            }

            double[] reL = new double[FRAME_SAMPLES];
            double[] imL = new double[FRAME_SAMPLES];
            double[] reR = new double[FRAME_SAMPLES];
            double[] imR = new double[FRAME_SAMPLES];
            for (int i = 0; i < FRAME_SAMPLES; i++) {
                double w = 0.5 - 0.5 * Math.cos(2.0 * Math.PI * i / (FRAME_SAMPLES - 1));
                reL[i] = (l[i] - meanL) * w;
                reR[i] = (r[i] - meanR) * w;
            }
            fft(reL, imL);
            fft(reR, imR);
            double[] eL = bandEnergy(reL, imL, sr);
            double[] eR = bandEnergy(reR, imR, sr);
            double ildLow = 10 * Math.log10((eR[0] + 1e-18) / (eL[0] + 1e-18));
            double ildMid = 10 * Math.log10((eR[1] + 1e-18) / (eL[1] + 1e-18));
            double ildHigh = 10 * Math.log10((eR[2] + 1e-18) / (eL[2] + 1e-18));
            return new Feature(bestLag, ildLow, ildMid, ildHigh, Math.max(-1, Math.min(1, best)), rmsDb);
        }

        private static double[] bandEnergy(double[] re, double[] im, int sr) {
            double[] e = new double[3];
            int ny = re.length / 2;
            for (int k = 1; k < ny; k++) {
                double hz = (double) k * sr / re.length;
                int band = hz >= 300 && hz < 1200 ? 0 : hz >= 1200 && hz < 3000 ? 1 : hz >= 3000 && hz < 8000 ? 2 : -1;
                if (band >= 0) e[band] += re[k] * re[k] + im[k] * im[k];
            }
            return e;
        }

        private static void fft(double[] re, double[] im) {
            int n = re.length;
            for (int i = 1, j = 0; i < n; i++) {
                int bit = n >> 1;
                for (; (j & bit) != 0; bit >>= 1) j ^= bit;
                j ^= bit;
                if (i < j) {
                    double tr = re[i]; re[i] = re[j]; re[j] = tr;
                    double ti = im[i]; im[i] = im[j]; im[j] = ti;
                }
            }
            for (int len = 2; len <= n; len <<= 1) {
                double ang = -2 * Math.PI / len;
                double wLenR = Math.cos(ang), wLenI = Math.sin(ang);
                for (int i = 0; i < n; i += len) {
                    double wr = 1, wi = 0;
                    for (int j = 0; j < len / 2; j++) {
                        int u = i + j, v = i + j + len / 2;
                        double vr = re[v] * wr - im[v] * wi;
                        double vi = re[v] * wi + im[v] * wr;
                        double ur = re[u], ui = im[u];
                        re[u] = ur + vr; im[u] = ui + vi;
                        re[v] = ur - vr; im[v] = ui - vi;
                        double nwr = wr * wLenR - wi * wLenI;
                        wi = wr * wLenI + wi * wLenR;
                        wr = nwr;
                    }
                }
            }
        }
    }
}
