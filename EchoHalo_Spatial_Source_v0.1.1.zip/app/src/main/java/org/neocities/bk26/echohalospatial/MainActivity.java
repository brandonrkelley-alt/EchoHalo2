package org.neocities.bk26.echohalospatial;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.method.ScrollingMovementMethod;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.io.FileInputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final String VERSION = "0.3.0";
    private static final int REQ_NOTIFICATIONS = 71;
    private boolean pendingStartWitness = false;
    private TextView statusView;
    private TextView reportView;
    private Button copyButton;
    private Button shareButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        buildUi();
        refreshReport();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshReport();
    }

    private void buildUi() {
        ScrollView scroller = new ScrollView(this);
        scroller.setFillViewport(true);
        scroller.setBackgroundColor(Color.BLACK);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(18), dp(20), dp(28));
        root.setBackgroundColor(Color.BLACK);
        scroller.addView(root, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT,
                ScrollView.LayoutParams.WRAP_CONTENT));

        root.addView(text("EchoHalo Route Witness", 28, Color.WHITE, true));
        TextView subtitle = text("Samsung Camera microphone-route observer · v" + VERSION, 15, 0xFF9AA0A6, false);
        subtitle.setPadding(0, dp(2), 0, dp(18));
        root.addView(subtitle);

        root.addView(cardText(
                "MISSION\nWatch Samsung's own Camera app while Pro Video switches OMNI → FRONT → REAR. EchoHalo does not record audio during this test; it only logs the routing information Android exposes about the Camera recording session.",
                17, 0xFFFFD17A));

        statusView = text("Ready. Start the witness before opening Samsung Camera.", 15, 0xFF9AA0A6, false);
        statusView.setPadding(0, dp(16), 0, dp(10));
        root.addView(statusView);

        Button start = button("Start Route Witness");
        start.setOnClickListener(v -> startWitness());
        root.addView(start);

        Button camera = button("Open Samsung Camera");
        camera.setOnClickListener(v -> openCamera());
        LinearLayout.LayoutParams cameraLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(52));
        cameraLp.setMargins(0, dp(8), 0, 0);
        root.addView(camera, cameraLp);

        Button stop = button("Stop Witness & Load Report");
        stop.setOnClickListener(v -> stopWitness());
        LinearLayout.LayoutParams stopLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(52));
        stopLp.setMargins(0, dp(8), 0, 0);
        root.addView(stop, stopLp);

        TextView steps = cardText(
                "CAMERA TEST\n" +
                "1. Tap Start Route Witness.\n" +
                "2. Open Samsung Camera → More → Pro Video.\n" +
                "3. Select OMNI. Pull down the notification shade and tap MARK OMNI, then record 3–5 seconds while speaking. Stop recording.\n" +
                "4. Select FRONT → MARK FRONT → record 3–5 seconds.\n" +
                "5. Select REAR → MARK REAR → record 3–5 seconds.\n" +
                "6. Return here and tap Stop Witness & Load Report.\n\n" +
                "The persistent notification is intentional: it keeps this diagnostic alive while Camera is in front. It does not capture microphone audio.",
                14, 0xFFB8C0C8);
        LinearLayout.LayoutParams stepsLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        stepsLp.setMargins(0, dp(14), 0, dp(14));
        root.addView(steps, stepsLp);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        copyButton = button("Copy Report");
        shareButton = button("Share Report");
        copyButton.setOnClickListener(v -> copyReport());
        shareButton.setOnClickListener(v -> shareReport());
        actions.addView(copyButton, weighted());
        actions.addView(space(dp(8)));
        actions.addView(shareButton, weighted());
        root.addView(actions);

        Button refresh = button("Refresh Report");
        refresh.setOnClickListener(v -> refreshReport());
        LinearLayout.LayoutParams refreshLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(50));
        refreshLp.setMargins(0, dp(8), 0, 0);
        root.addView(refresh, refreshLp);

        Button openEchoHalo = button("Open EchoHalo");
        openEchoHalo.setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_VIEW,
                Uri.parse("https://bk26.neocities.org/EchoHalo/"))));
        LinearLayout.LayoutParams openLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(50));
        openLp.setMargins(0, dp(8), 0, dp(16));
        root.addView(openEchoHalo, openLp);

        reportView = text("No route-witness report yet.", 12, 0xFFCED4DA, false);
        reportView.setTypeface(android.graphics.Typeface.MONOSPACE);
        reportView.setTextIsSelectable(true);
        reportView.setMovementMethod(new ScrollingMovementMethod());
        reportView.setPadding(dp(14), dp(14), dp(14), dp(14));
        reportView.setBackground(makeCardBackground(0xFF080808, 0xFF2B2B2B, 14));
        root.addView(reportView);

        TextView footer = text(
                "Diagnostic only. EchoHalo does not record the Camera audio or alter Samsung microphone settings.",
                12, 0xFF737980, false);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(18), 0, 0);
        root.addView(footer);

        setContentView(scroller);
    }

    private void startWitness() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            pendingStartWitness = true;
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
            return;
        }
        startWitnessNow();
    }

    private void startWitnessNow() {
        Intent i = new Intent(this, RouteWitnessService.class);
        i.setAction(RouteWitnessService.ACTION_START);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        statusView.setText("Witness running. Open Samsung Camera and test OMNI → FRONT → REAR.");
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_NOTIFICATIONS && pendingStartWitness) {
            pendingStartWitness = false;
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startWitnessNow();
            } else {
                statusView.setText("Notification permission was denied. The witness can still run, but OMNI/FRONT/REAR marker buttons may not be visible. Starting anyway.");
                startWitnessNow();
            }
        }
    }

    private void stopWitness() {
        Intent i = new Intent(this, RouteWitnessService.class);
        i.setAction(RouteWitnessService.ACTION_STOP);
        startService(i);
        statusView.setText("Stopping witness… tap Refresh Report in a moment if the final lines have not appeared yet.");
        reportView.postDelayed(this::refreshReport, 500);
    }

    private void openCamera() {
        try {
            Intent i = new Intent(MediaStore.INTENT_ACTION_VIDEO_CAMERA);
            startActivity(i);
        } catch (Exception e) {
            statusView.setText("Could not open Camera automatically. Open Samsung Camera manually, then choose Pro Video.");
        }
    }

    private void refreshReport() {
        File f = new File(getFilesDir(), RouteWitnessService.REPORT_FILE);
        if (!f.exists()) {
            if (reportView != null) reportView.setText("No route-witness report yet.");
            if (copyButton != null) copyButton.setEnabled(false);
            if (shareButton != null) shareButton.setEnabled(false);
            return;
        }
        try (FileInputStream in = new FileInputStream(f)) {
            byte[] data = new byte[(int) f.length()];
            int n = in.read(data);
            String s = new String(data, 0, Math.max(0, n), StandardCharsets.UTF_8);
            reportView.setText(s);
            copyButton.setEnabled(!s.isEmpty());
            shareButton.setEnabled(!s.isEmpty());
        } catch (Exception e) {
            reportView.setText("Could not read report: " + e.getClass().getSimpleName() + ": " + e.getMessage());
        }
    }

    private String reportText() {
        return reportView == null ? "" : reportView.getText().toString();
    }

    private void copyReport() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("EchoHalo Route Witness", reportText()));
        statusView.setText("Route Witness report copied.");
    }

    private void shareReport() {
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("text/plain");
        share.putExtra(Intent.EXTRA_SUBJECT, "EchoHalo Route Witness v" + VERSION);
        share.putExtra(Intent.EXTRA_TEXT, reportText());
        startActivity(Intent.createChooser(share, "Share EchoHalo report"));
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        return t;
    }

    private TextView cardText(String value, int sp, int color) {
        TextView t = text(value, sp, color, true);
        t.setPadding(dp(16), dp(14), dp(16), dp(14));
        t.setBackground(makeCardBackground(0xFF080808, 0xFF2B2B2B, 16));
        return t;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(16);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setBackground(makeCardBackground(0xFF111619, 0xFF4CBBC3, 15));
        b.setPadding(dp(12), 0, dp(12), 0);
        b.setMinHeight(dp(52));
        return b;
    }

    private LinearLayout.LayoutParams weighted() {
        return new LinearLayout.LayoutParams(0, dp(50), 1f);
    }

    private View space(int width) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(width, 1));
        return v;
    }

    private android.graphics.drawable.Drawable makeCardBackground(int fill, int stroke, int radiusDp) {
        android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
        gd.setColor(fill);
        gd.setCornerRadius(dp(radiusDp));
        gd.setStroke(dp(1), stroke);
        return gd;
    }

    private int dp(int n) {
        return Math.round(n * getResources().getDisplayMetrics().density);
    }
}
