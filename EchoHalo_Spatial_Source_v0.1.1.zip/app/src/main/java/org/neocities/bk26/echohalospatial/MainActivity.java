package org.neocities.bk26.echohalospatial;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.AudioDeviceInfo;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioRecordingConfiguration;
import android.media.MediaRecorder;
import android.media.MicrophoneDirection;
import android.media.MicrophoneInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Pair;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQ_RECORD_AUDIO = 40;
    private static final int SAMPLE_RATE = 48000;
    private static final String VERSION = "0.2.0";

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private TextView statusView;
    private TextView verdictView;
    private TextView reportView;
    private Button huntButton;
    private Button copyButton;
    private Button shareButton;
    private String lastReport = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        buildUi();
        updatePermissionState();
    }

    @Override
    protected void onDestroy() {
        worker.shutdownNow();
        super.onDestroy();
    }

    private void buildUi() {
        ScrollView scroller = new ScrollView(this);
        scroller.setFillViewport(true);
        scroller.setBackgroundColor(Color.BLACK);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(18), dp(20), dp(28));
        root.setBackgroundColor(Color.BLACK);
        scroller.addView(root, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT,
                ScrollView.LayoutParams.WRAP_CONTENT));

        root.addView(text("EchoHalo Third Mic Hunter", 28, Color.WHITE, true));
        TextView subtitle = text("Samsung microphone route discovery · v" + VERSION, 15, 0xFF9AA0A6, false);
        subtitle.setPadding(0, dp(2), 0, dp(18));
        root.addView(subtitle);

        verdictView = cardText(
                "MISSION\nFind whether Samsung exposes the SPK_3rdMic path to an ordinary Android app through any documented recording route.",
                17, 0xFFFFD17A);
        root.addView(verdictView);

        statusView = text("Microphone permission has not been checked yet.", 15, 0xFF9AA0A6, false);
        statusView.setPadding(0, dp(16), 0, dp(10));
        root.addView(statusView);

        huntButton = button("Find Third Mic");
        huntButton.setOnClickListener(v -> ensurePermissionAndRun());
        root.addView(huntButton);

        TextView tip = cardText(
                "WHAT THIS BUILD DOES\n" +
                "1. Enumerates every public Android input and physical microphone.\n" +
                "2. Forces each selectable input device through multiple AudioSource modes.\n" +
                "3. Compares preferred device vs the device Samsung actually routes.\n" +
                "4. Tries Android's front/back microphone-direction hints and audio zoom.\n" +
                "5. Flags any NEW physical microphone ID that appears during a test.\n\n" +
                "This probe uses documented Android APIs only. It does not invoke Samsung factory services or alter firmware.",
                14, 0xFFB8C0C8);
        LinearLayout.LayoutParams tipLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        tipLp.setMargins(0, dp(14), 0, dp(14));
        root.addView(tip, tipLp);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        copyButton = button("Copy Report");
        shareButton = button("Share Report");
        copyButton.setEnabled(false);
        shareButton.setEnabled(false);
        copyButton.setOnClickListener(v -> copyReport());
        shareButton.setOnClickListener(v -> shareReport());
        actions.addView(copyButton, weighted());
        actions.addView(space(dp(8)));
        actions.addView(shareButton, weighted());
        root.addView(actions);

        Button openEchoHalo = button("Open EchoHalo");
        openEchoHalo.setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_VIEW,
                Uri.parse("https://bk26.neocities.org/EchoHalo/"))));
        LinearLayout.LayoutParams openLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(50));
        openLp.setMargins(0, dp(8), 0, dp(16));
        root.addView(openEchoHalo, openLp);

        reportView = text("No report yet.", 12, 0xFFCED4DA, false);
        reportView.setTypeface(android.graphics.Typeface.MONOSPACE);
        reportView.setTextIsSelectable(true);
        reportView.setMovementMethod(new ScrollingMovementMethod());
        reportView.setPadding(dp(14), dp(14), dp(14), dp(14));
        reportView.setBackground(makeCardBackground(0xFF080808, 0xFF2B2B2B, 14));
        root.addView(reportView);

        TextView footer = text(
                "Diagnostic only. No cochlear-implant settings or Samsung factory settings are changed.",
                12, 0xFF737980, false);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(18), 0, 0);
        root.addView(footer);

        setContentView(scroller);
    }

    private void updatePermissionState() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            statusView.setText("Microphone permission granted. Ready to hunt Samsung's hidden third microphone route.");
        } else {
            statusView.setText("Tap Find Third Mic, then allow microphone access.");
        }
    }

    private void ensurePermissionAndRun() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_RECORD_AUDIO);
            return;
        }
        runHunt();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_RECORD_AUDIO) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                updatePermissionState();
                runHunt();
            } else {
                statusView.setText("Microphone permission denied.");
            }
        }
    }

    private void runHunt() {
        huntButton.setEnabled(false);
        copyButton.setEnabled(false);
        shareButton.setEnabled(false);
        statusView.setText("Hunting… keep the phone uncovered and speak normally for about 20 seconds.");
        verdictView.setText("SEARCHING\nTesting routing, source modes, active microphone IDs, and front/back direction hints.");
        reportView.setText("Starting third-mic hunt…");

        worker.execute(() -> {
            HuntResult result = performHunt();
            runOnUiThread(() -> {
                lastReport = result.report;
                reportView.setText(result.report);
                verdictView.setText(result.title + "\n" + result.detail);
                statusView.setText("Third-mic hunt complete. Copy or share the report back to ChatGPT.");
                huntButton.setEnabled(true);
                copyButton.setEnabled(true);
                shareButton.setEnabled(true);
            });
        });
    }

    private HuntResult performHunt() {
        AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        StringBuilder out = new StringBuilder();
        String timestamp = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ", Locale.US).format(new Date());
        out.append("EchoHalo Third Mic Hunter v").append(VERSION).append('\n');
        out.append("Time: ").append(timestamp).append('\n');
        out.append("Device: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append('\n');
        out.append("Android: ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n");
        out.append("Fingerprint: ").append(Build.FINGERPRINT).append("\n\n");

        AudioDeviceInfo[] inputs = am.getDevices(AudioManager.GET_DEVICES_INPUTS);
        List<AudioDeviceInfo> physicalCandidates = new ArrayList<>();
        out.append("INPUT DEVICE INVENTORY\n");
        for (AudioDeviceInfo d : inputs) {
            out.append("  id=").append(d.getId())
                    .append(" type=").append(deviceTypeName(d.getType()))
                    .append(" address=").append(safe(d.getAddress()))
                    .append(" product=").append(safe(d.getProductName()))
                    .append(" source=").append(d.isSource())
                    .append(" channels=").append(intArray(d.getChannelCounts()))
                    .append(" rates=").append(intArray(d.getSampleRates())).append('\n');
            if (d.isSource() && d.getType() != AudioDeviceInfo.TYPE_REMOTE_SUBMIX && d.getType() != AudioDeviceInfo.TYPE_TELEPHONY) {
                physicalCandidates.add(d);
            }
        }

        Set<Integer> baselineMicIds = new HashSet<>();
        out.append("\nPUBLIC MICROPHONE INVENTORY\n");
        try {
            List<MicrophoneInfo> mics = am.getMicrophones();
            out.append("Microphones reported: ").append(mics.size()).append('\n');
            for (int i = 0; i < mics.size(); i++) {
                MicrophoneInfo m = mics.get(i);
                if (m.getType() == AudioDeviceInfo.TYPE_BUILTIN_MIC && m.getLocation() == MicrophoneInfo.LOCATION_MAINBODY) {
                    baselineMicIds.add(m.getId());
                }
                out.append(describeMic("MIC " + i, m, false));
            }
        } catch (Exception e) {
            out.append("getMicrophones failed: ").append(e.getClass().getSimpleName()).append(": ").append(safe(e.getMessage())).append('\n');
        }
        out.append("Baseline MAINBODY built-in mic IDs: ").append(baselineMicIds).append("\n");

        out.append("\nREAD-ONLY AUDIO HAL PARAMETER CLUES\n");
        String[] parameterKeys = {
                "mic_mode", "input_source", "audio_source", "recording_mode", "camera_direction",
                "mic_index", "mic_num", "dual_mic", "triple_mic", "loopback", "factory_test"
        };
        for (String key : parameterKeys) {
            try {
                String value = am.getParameters(key);
                out.append("  ").append(key).append(" => ").append(value == null || value.trim().isEmpty() ? "<empty>" : value).append('\n');
            } catch (Exception e) {
                out.append("  ").append(key).append(" => ").append(e.getClass().getSimpleName()).append('\n');
            }
        }

        int[] sources = buildSources();
        Set<Integer> newlySeenMicIds = new HashSet<>();
        Set<Integer> allActiveMicIds = new HashSet<>();
        boolean routedToBack = false;
        boolean routedToBottom = false;

        out.append("\nPREFERRED-DEVICE ROUTING MATRIX\n");
        for (AudioDeviceInfo device : physicalCandidates) {
            out.append("\n-- preferred device id=").append(device.getId())
                    .append(" type=").append(deviceTypeName(device.getType()))
                    .append(" address=").append(safe(device.getAddress())).append(" --\n");
            for (int source : sources) {
                RouteResult rr = routeProbe(device, source, 1, MicrophoneDirection.MIC_DIRECTION_UNSPECIFIED, 0f);
                out.append(rr.text);
                allActiveMicIds.addAll(rr.activeMicIds);
                for (int id : rr.activeMicIds) if (!baselineMicIds.contains(id)) newlySeenMicIds.add(id);
                routedToBack |= rr.routedAddress.toLowerCase(Locale.US).contains("back");
                routedToBottom |= rr.routedAddress.toLowerCase(Locale.US).contains("bottom");
            }
        }

        out.append("\nDIRECTION-HINT PROBE (CAMCORDER, 2ch)\n");
        int[] directions = {
                MicrophoneDirection.MIC_DIRECTION_UNSPECIFIED,
                MicrophoneDirection.MIC_DIRECTION_TOWARDS_USER,
                MicrophoneDirection.MIC_DIRECTION_AWAY_FROM_USER,
                MicrophoneDirection.MIC_DIRECTION_EXTERNAL
        };
        float[] zooms = {0f, 1f, -1f};
        for (int direction : directions) {
            for (float zoom : zooms) {
                RouteResult rr = routeProbe(null, MediaRecorder.AudioSource.CAMCORDER, 2, direction, zoom);
                out.append("  direction=").append(directionName(direction)).append(" zoom=")
                        .append(String.format(Locale.US, "%.1f", zoom)).append('\n');
                out.append(indent(rr.text, 4));
                allActiveMicIds.addAll(rr.activeMicIds);
                for (int id : rr.activeMicIds) if (!baselineMicIds.contains(id)) newlySeenMicIds.add(id);
            }
        }

        out.append("\nSUMMARY\n");
        out.append("Baseline built-in IDs: ").append(baselineMicIds).append('\n');
        out.append("All active mic IDs observed: ").append(allActiveMicIds).append('\n');
        out.append("NEW active IDs outside baseline: ").append(newlySeenMicIds).append('\n');
        out.append("Explicit bottom route observed: ").append(routedToBottom).append('\n');
        out.append("Explicit back route observed: ").append(routedToBack).append('\n');

        String title;
        String detail;
        if (!newlySeenMicIds.isEmpty()) {
            title = "THIRD-MIC CANDIDATE FOUND";
            detail = "A recording configuration exposed an active microphone ID that was not part of the normal built-in inventory. Send the report so we can identify which route revealed it.";
            out.append("Verdict: THIRD-MIC CANDIDATE FOUND.\n");
        } else {
            title = "THIRD MIC STILL HAL-HIDDEN";
            detail = "Samsung's factory loopback can select SPK_3rdMic, but every documented app-level route still resolves to the public bottom/back microphones. The report tells us whether direction hints or explicit routing changed Samsung's processing.";
            out.append("Verdict: No new physical microphone ID became visible through documented Android app APIs.\n");
        }
        out.append("\nNote: SPK_3rdMic existing in Samsung's factory menu proves the hardware route exists; this test asks whether an ordinary third-party app can reach that route without privileged Samsung services.\n");
        return new HuntResult(out.toString(), title, detail);
    }

    private int[] buildSources() {
        if (Build.VERSION.SDK_INT >= 29) {
            return new int[]{
                    MediaRecorder.AudioSource.DEFAULT,
                    MediaRecorder.AudioSource.MIC,
                    MediaRecorder.AudioSource.CAMCORDER,
                    MediaRecorder.AudioSource.UNPROCESSED,
                    MediaRecorder.AudioSource.VOICE_RECOGNITION,
                    MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                    MediaRecorder.AudioSource.VOICE_PERFORMANCE
            };
        }
        return new int[]{
                MediaRecorder.AudioSource.DEFAULT,
                MediaRecorder.AudioSource.MIC,
                MediaRecorder.AudioSource.CAMCORDER,
                MediaRecorder.AudioSource.UNPROCESSED,
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                MediaRecorder.AudioSource.VOICE_COMMUNICATION
        };
    }

    private RouteResult routeProbe(AudioDeviceInfo preferredDevice, int source, int channels, int direction, float zoom) {
        StringBuilder out = new StringBuilder();
        AudioRecord record = null;
        Set<Integer> activeMicIds = new HashSet<>();
        String routedAddress = "";
        try {
            int channelIndexMask = (1 << channels) - 1;
            AudioFormat format = new AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SAMPLE_RATE)
                    .setChannelIndexMask(channelIndexMask)
                    .build();
            int bufferBytes = Math.max(32768, SAMPLE_RATE * channels * 2);
            record = new AudioRecord.Builder()
                    .setAudioSource(source)
                    .setAudioFormat(format)
                    .setBufferSizeInBytes(bufferBytes)
                    .build();
            if (record.getState() != AudioRecord.STATE_INITIALIZED) {
                return RouteResult.fail("    " + sourceName(source) + ": NOT INITIALIZED\n");
            }

            boolean preferredAccepted = true;
            if (preferredDevice != null) preferredAccepted = record.setPreferredDevice(preferredDevice);
            boolean directionAccepted = true;
            boolean zoomAccepted = true;
            if (Build.VERSION.SDK_INT >= 29) {
                directionAccepted = record.setPreferredMicrophoneDirection(direction);
                zoomAccepted = record.setPreferredMicrophoneFieldDimension(zoom);
            }

            record.startRecording();
            Thread.sleep(120);
            AudioDeviceInfo routed = record.getRoutedDevice();
            if (routed != null) routedAddress = safe(routed.getAddress());
            List<MicrophoneInfo> active = record.getActiveMicrophones();
            for (MicrophoneInfo m : active) activeMicIds.add(m.getId());

            int actualChannels = record.getChannelCount();
            int frames = SAMPLE_RATE / 5;
            short[] data = new short[frames * Math.max(1, actualChannels)];
            int read = record.read(data, 0, data.length, AudioRecord.READ_BLOCKING);

            out.append("    ").append(sourceName(source))
                    .append(" preferredAccepted=").append(preferredAccepted)
                    .append(" directionAccepted=").append(directionAccepted)
                    .append(" zoomAccepted=").append(zoomAccepted)
                    .append(" actual=").append(actualChannels).append("ch")
                    .append(" activeIDs=").append(activeMicIds);
            if (routed != null) {
                out.append(" routed=id").append(routed.getId())
                        .append('/').append(deviceTypeName(routed.getType()))
                        .append('/').append(safe(routed.getAddress()));
            } else {
                out.append(" routed=<null>");
            }
            out.append('\n');

            for (MicrophoneInfo m : active) out.append(indent(describeMic("active", m, true), 6));

            if (read > 0) {
                double[] rms = channelRms(data, read, actualChannels);
                out.append("      RMS:");
                for (int ch = 0; ch < rms.length; ch++) {
                    out.append(" CH").append(ch + 1).append('=').append(String.format(Locale.US, "%.5f", rms[ch]));
                }
                if (actualChannels >= 2) {
                    CorrLag cl = bestCorrelationLag(data, read, actualChannels, 0, 1, 32);
                    out.append(" | CH1↔CH2 corr=").append(String.format(Locale.US, "%.3f", cl.correlation))
                            .append(" lag=").append(cl.lagSamples);
                }
                out.append('\n');
            }
            return RouteResult.ok(out.toString(), activeMicIds, routedAddress);
        } catch (SecurityException e) {
            return RouteResult.fail("    " + sourceName(source) + ": SECURITY " + safe(e.getMessage()) + "\n");
        } catch (Exception e) {
            return RouteResult.fail("    " + sourceName(source) + ": " + e.getClass().getSimpleName() + " " + safe(e.getMessage()) + "\n");
        } finally {
            if (record != null) {
                try { if (record.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) record.stop(); } catch (Exception ignored) {}
                try { record.release(); } catch (Exception ignored) {}
            }
        }
    }

    private String describeMic(String prefix, MicrophoneInfo mic, boolean includeMapping) {
        StringBuilder s = new StringBuilder();
        s.append(prefix).append(": id=").append(mic.getId())
                .append(" desc=").append(safe(mic.getDescription()))
                .append(" type=").append(deviceTypeName(mic.getType()))
                .append(" address=").append(safe(mic.getAddress()))
                .append(" location=").append(locationName(mic.getLocation()))
                .append(" group=").append(mic.getGroup())
                .append(" index=").append(mic.getIndexInTheGroup())
                .append(" directionality=").append(directionalityName(mic.getDirectionality())).append('\n');
        s.append("  position(m)=").append(coord(mic.getPosition()))
                .append(" orientation=").append(coord(mic.getOrientation()))
                .append(" sensitivity=").append(floatValue(mic.getSensitivity()))
                .append(" minSPL=").append(floatValue(mic.getMinSpl()))
                .append(" maxSPL=").append(floatValue(mic.getMaxSpl())).append('\n');
        if (includeMapping) {
            s.append("  mapping=");
            List<Pair<Integer, Integer>> mappings = mic.getChannelMapping();
            if (mappings.isEmpty()) s.append("none");
            for (int i = 0; i < mappings.size(); i++) {
                if (i > 0) s.append(", ");
                Pair<Integer, Integer> m = mappings.get(i);
                int ch = m.first == null ? -1 : m.first;
                int map = m.second == null ? -1 : m.second;
                s.append("CH").append(ch + 1).append(':').append(mappingName(map));
            }
            s.append('\n');
        }
        return s.toString();
    }

    private double[] channelRms(short[] data, int read, int channels) {
        double[] sums = new double[channels];
        int[] counts = new int[channels];
        for (int i = 0; i < read; i++) {
            int ch = i % channels;
            double v = data[i] / 32768.0;
            sums[ch] += v * v;
            counts[ch]++;
        }
        double[] rms = new double[channels];
        for (int ch = 0; ch < channels; ch++) rms[ch] = counts[ch] == 0 ? 0 : Math.sqrt(sums[ch] / counts[ch]);
        return rms;
    }

    private CorrLag bestCorrelationLag(short[] data, int read, int channels, int a, int b, int maxLag) {
        int frames = read / channels;
        if (frames < 64) return new CorrLag(0, 0);
        int stride = Math.max(1, frames / 4000);
        double best = 0;
        int bestLag = 0;
        for (int lag = -maxLag; lag <= maxLag; lag++) {
            double xy = 0, x2 = 0, y2 = 0;
            int start = Math.max(0, -lag);
            int end = Math.min(frames, frames - lag);
            for (int f = start; f < end; f += stride) {
                double x = data[f * channels + a];
                double y = data[(f + lag) * channels + b];
                xy += x * y; x2 += x * x; y2 += y * y;
            }
            if (x2 > 0 && y2 > 0) {
                double c = xy / Math.sqrt(x2 * y2);
                if (Math.abs(c) > Math.abs(best)) { best = c; bestLag = lag; }
            }
        }
        return new CorrLag(best, bestLag);
    }

    private void copyReport() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("EchoHalo Third Mic Hunter", lastReport));
        statusView.setText("Report copied.");
    }

    private void shareReport() {
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_SUBJECT, "EchoHalo Third Mic Hunter v" + VERSION);
        send.putExtra(Intent.EXTRA_TEXT, lastReport);
        startActivity(Intent.createChooser(send, "Share third-mic report"));
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(sp); t.setTextColor(color);
        if (bold) t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView cardText(String value, int sp, int color) {
        TextView t = text(value, sp, color, true);
        t.setPadding(dp(16), dp(16), dp(16), dp(16));
        t.setBackground(makeCardBackground(0xFF080808, 0xFF303030, 14));
        return t;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label); b.setTextSize(15); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setMinHeight(dp(50));
        b.setBackground(makeCardBackground(0xFF111718, 0xFF3E8E92, 14));
        return b;
    }

    private LinearLayout.LayoutParams weighted() { return new LinearLayout.LayoutParams(0, dp(50), 1f); }
    private View space(int px) { View v = new View(this); v.setLayoutParams(new LinearLayout.LayoutParams(px, 1)); return v; }
    private android.graphics.drawable.Drawable makeCardBackground(int fill, int stroke, int radiusDp) {
        android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
        gd.setColor(fill); gd.setCornerRadius(dp(radiusDp)); gd.setStroke(dp(1), stroke); return gd;
    }
    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }

    private static String safe(Object o) { return o == null ? "" : String.valueOf(o); }
    private static String intArray(int[] values) {
        if (values == null || values.length == 0) return "[]";
        StringBuilder s = new StringBuilder("[");
        for (int i = 0; i < values.length; i++) { if (i > 0) s.append(','); s.append(values[i]); }
        return s.append(']').toString();
    }
    private static String coord(MicrophoneInfo.Coordinate3F c) {
        if (c == null || unknownFloat(c.x) || unknownFloat(c.y) || unknownFloat(c.z)) return "unknown";
        return String.format(Locale.US, "(%.4f, %.4f, %.4f)", c.x, c.y, c.z);
    }
    private static String floatValue(float f) {
        if (Float.isNaN(f) || unknownFloat(f)) return "unknown";
        return String.format(Locale.US, "%.2f", f);
    }
    private static boolean unknownFloat(float f) { return !Float.isFinite(f) || Math.abs(f) > 1.0e20f; }
    private static String mappingName(int mapping) {
        if (mapping == MicrophoneInfo.CHANNEL_MAPPING_DIRECT) return "DIRECT";
        if (mapping == MicrophoneInfo.CHANNEL_MAPPING_PROCESSED) return "PROCESSED";
        return "UNKNOWN(" + mapping + ")";
    }
    private static String locationName(int loc) {
        switch (loc) {
            case MicrophoneInfo.LOCATION_MAINBODY: return "MAINBODY";
            case MicrophoneInfo.LOCATION_MAINBODY_MOVABLE: return "MAINBODY_MOVABLE";
            case MicrophoneInfo.LOCATION_PERIPHERAL: return "PERIPHERAL";
            default: return "UNKNOWN(" + loc + ")";
        }
    }
    private static String directionalityName(int d) {
        switch (d) {
            case MicrophoneInfo.DIRECTIONALITY_OMNI: return "OMNI";
            case MicrophoneInfo.DIRECTIONALITY_BI_DIRECTIONAL: return "BI_DIRECTIONAL";
            case MicrophoneInfo.DIRECTIONALITY_CARDIOID: return "CARDIOID";
            case MicrophoneInfo.DIRECTIONALITY_HYPER_CARDIOID: return "HYPER_CARDIOID";
            case MicrophoneInfo.DIRECTIONALITY_SUPER_CARDIOID: return "SUPER_CARDIOID";
            default: return "UNKNOWN(" + d + ")";
        }
    }
    private static String deviceTypeName(int type) {
        switch (type) {
            case AudioDeviceInfo.TYPE_BUILTIN_MIC: return "BUILTIN_MIC";
            case AudioDeviceInfo.TYPE_TELEPHONY: return "TELEPHONY";
            case AudioDeviceInfo.TYPE_REMOTE_SUBMIX: return "REMOTE_SUBMIX";
            case AudioDeviceInfo.TYPE_BLUETOOTH_SCO: return "BLUETOOTH_SCO";
            case AudioDeviceInfo.TYPE_WIRED_HEADSET: return "WIRED_HEADSET";
            case AudioDeviceInfo.TYPE_USB_DEVICE: return "USB_DEVICE";
            case AudioDeviceInfo.TYPE_USB_HEADSET: return "USB_HEADSET";
            default: return "TYPE_" + type;
        }
    }
    private static String sourceName(int source) {
        if (source == MediaRecorder.AudioSource.DEFAULT) return "DEFAULT";
        if (source == MediaRecorder.AudioSource.MIC) return "MIC";
        if (source == MediaRecorder.AudioSource.CAMCORDER) return "CAMCORDER";
        if (source == MediaRecorder.AudioSource.UNPROCESSED) return "UNPROCESSED";
        if (source == MediaRecorder.AudioSource.VOICE_RECOGNITION) return "VOICE_RECOGNITION";
        if (source == MediaRecorder.AudioSource.VOICE_COMMUNICATION) return "VOICE_COMMUNICATION";
        if (Build.VERSION.SDK_INT >= 29 && source == MediaRecorder.AudioSource.VOICE_PERFORMANCE) return "VOICE_PERFORMANCE";
        return "SOURCE_" + source;
    }
    private static String directionName(int direction) {
        switch (direction) {
            case MicrophoneDirection.MIC_DIRECTION_UNSPECIFIED: return "UNSPECIFIED";
            case MicrophoneDirection.MIC_DIRECTION_TOWARDS_USER: return "TOWARDS_USER";
            case MicrophoneDirection.MIC_DIRECTION_AWAY_FROM_USER: return "AWAY_FROM_USER";
            case MicrophoneDirection.MIC_DIRECTION_EXTERNAL: return "EXTERNAL";
            default: return "DIR_" + direction;
        }
    }
    private static String indent(String value, int spaces) {
        StringBuilder padBuilder = new StringBuilder();
        for (int i = 0; i < spaces; i++) padBuilder.append(' ');
        String pad = padBuilder.toString();
        return pad + value.replace("\n", "\n" + pad);
    }

    private static final class CorrLag {
        final double correlation; final int lagSamples;
        CorrLag(double correlation, int lagSamples) { this.correlation = correlation; this.lagSamples = lagSamples; }
    }
    private static final class HuntResult {
        final String report, title, detail;
        HuntResult(String report, String title, String detail) { this.report = report; this.title = title; this.detail = detail; }
    }
    private static final class RouteResult {
        final boolean success; final String text; final Set<Integer> activeMicIds; final String routedAddress;
        private RouteResult(boolean success, String text, Set<Integer> ids, String routedAddress) {
            this.success = success; this.text = text; this.activeMicIds = ids; this.routedAddress = routedAddress;
        }
        static RouteResult fail(String text) { return new RouteResult(false, text, new HashSet<>(), ""); }
        static RouteResult ok(String text, Set<Integer> ids, String routedAddress) { return new RouteResult(true, text, ids, routedAddress); }
    }
}
