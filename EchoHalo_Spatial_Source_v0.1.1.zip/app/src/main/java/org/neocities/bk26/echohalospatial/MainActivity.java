package org.neocities.bk26.echohalospatial;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.AudioDeviceInfo;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioRecordingConfiguration;
import android.media.MediaRecorder;
import android.media.MicrophoneInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.method.ScrollingMovementMethod;
import android.util.Pair;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQ_RECORD_AUDIO = 40;
    private static final int SAMPLE_RATE = 48000;
    private static final int[] CHANNEL_COUNTS = {1, 2, 3, 4};

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private TextView statusView;
    private TextView verdictView;
    private TextView reportView;
    private Button probeButton;
    private Button copyButton;
    private Button shareButton;
    private String lastReport = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        buildUi();
        updatePermissionState();
    }

    @Override
    protected void onDestroy() {
        worker.shutdownNow();
        super.onDestroy();
    }

    private void buildUi() {
        ScrollView scroller = new ScrollView(this);
        scroller.setFillViewport(true);
        scroller.setBackgroundColor(Color.BLACK);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(18), dp(20), dp(28));
        root.setBackgroundColor(Color.BLACK);
        scroller.addView(root, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT,
                ScrollView.LayoutParams.WRAP_CONTENT));

        TextView title = text("EchoHalo Spatial Probe", 28, Color.WHITE, true);
        root.addView(title);
        TextView subtitle = text("Native microphone-array diagnostics · v0.1.0", 15, 0xFF9AA0A6, false);
        subtitle.setPadding(0, dp(2), 0, dp(18));
        root.addView(subtitle);

        verdictView = cardText("READY\nThis native probe asks Android what microphones and channel mappings the phone actually exposes.", 17, 0xFFFFD17A);
        root.addView(verdictView);

        statusView = text("Microphone permission has not been checked yet.", 15, 0xFF9AA0A6, false);
        statusView.setPadding(0, dp(16), 0, dp(10));
        root.addView(statusView);

        probeButton = button("Run Spatial Probe");
        probeButton.setOnClickListener(v -> ensurePermissionAndRun());
        root.addView(probeButton);

        TextView tip = cardText(
                "HOW TO TEST\nKeep the phone uncovered. During the capture tests, speak continuously and slowly rotate the phone. The probe will try mono through 4-channel capture using DEFAULT, UNPROCESSED, VOICE_RECOGNITION, and CAMCORDER audio sources.",
                14, 0xFFB8C0C8);
        tip.setPadding(dp(16), dp(16), dp(16), dp(16));
        LinearLayout.LayoutParams tipLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        tipLp.setMargins(0, dp(14), 0, dp(14));
        root.addView(tip, tipLp);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        copyButton = button("Copy Report");
        shareButton = button("Share Report");
        Button openEchoHalo = button("Open EchoHalo");
        copyButton.setEnabled(false);
        shareButton.setEnabled(false);
        copyButton.setOnClickListener(v -> copyReport());
        shareButton.setOnClickListener(v -> shareReport());
        openEchoHalo.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://bk26.neocities.org/EchoHalo/"));
            startActivity(i);
        });
        actions.addView(copyButton, weighted());
        actions.addView(space(dp(8)));
        actions.addView(shareButton, weighted());
        root.addView(actions);
        LinearLayout.LayoutParams openLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(50));
        openLp.setMargins(0, dp(8), 0, dp(16));
        root.addView(openEchoHalo, openLp);

        reportView = text("No report yet.", 13, 0xFFCED4DA, false);
        reportView.setTypeface(android.graphics.Typeface.MONOSPACE);
        reportView.setTextIsSelectable(true);
        reportView.setMovementMethod(new ScrollingMovementMethod());
        reportView.setPadding(dp(14), dp(14), dp(14), dp(14));
        reportView.setBackground(makeCardBackground(0xFF080808, 0xFF2B2B2B, 14));
        root.addView(reportView);

        TextView footer = text(
                "Diagnostic tool only. It does not change cochlear-implant settings or microphone firmware.",
                12, 0xFF737980, false);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(18), 0, 0);
        root.addView(footer);

        setContentView(scroller);
    }

    private void updatePermissionState() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            statusView.setText("Microphone permission granted. Ready to probe Android's native audio stack.");
        } else {
            statusView.setText("Tap Run Spatial Probe, then allow microphone access.");
        }
    }

    private void ensurePermissionAndRun() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_RECORD_AUDIO);
            return;
        }
        runProbe();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_RECORD_AUDIO) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                updatePermissionState();
                runProbe();
            } else {
                statusView.setText("Microphone permission denied. The spatial probe cannot run without it.");
                verdictView.setText("PERMISSION NEEDED\nAllow microphone access to inspect active microphones and capture channels.");
            }
        }
    }

    private void runProbe() {
        probeButton.setEnabled(false);
        copyButton.setEnabled(false);
        shareButton.setEnabled(false);
        statusView.setText("Running native probe… speak and slowly rotate the phone.");
        verdictView.setText("PROBING\nAndroid is being asked for physical microphones, direct/processed mappings, and 1–4 channel capture.");
        reportView.setText("Starting…");

        worker.execute(() -> {
            ProbeSummary summary = performProbe();
            runOnUiThread(() -> {
                lastReport = summary.report;
                reportView.setText(summary.report);
                verdictView.setText(summary.verdictTitle + "\n" + summary.verdictDetail);
                statusView.setText("Probe complete. Copy or share the report back to ChatGPT.");
                probeButton.setEnabled(true);
                copyButton.setEnabled(true);
                shareButton.setEnabled(true);
            });
        });
    }

    private ProbeSummary performProbe() {
        StringBuilder out = new StringBuilder();
        AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        String timestamp = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ", Locale.US).format(new Date());

        out.append("EchoHalo Spatial Probe v0.1.0\n");
        out.append("Time: ").append(timestamp).append('\n');
        out.append("Device: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append('\n');
        out.append("Android: ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n");
        out.append("Build fingerprint: ").append(Build.FINGERPRINT).append("\n\n");

        String unprocessed = audioManager.getProperty(AudioManager.PROPERTY_SUPPORT_AUDIO_SOURCE_UNPROCESSED);
        out.append("UNPROCESSED advertised: ").append(unprocessed).append('\n');
        AudioDeviceInfo[] inputDevices = audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS);
        out.append("Android input devices: ").append(inputDevices.length).append('\n');
        for (AudioDeviceInfo d : inputDevices) {
            out.append("  device id=").append(d.getId())
                    .append(" type=").append(deviceTypeName(d.getType()))
                    .append(" product=").append(d.getProductName())
                    .append(" address=").append(safe(d.getAddress()))
                    .append(" channels=").append(intArray(d.getChannelCounts()))
                    .append(" rates=").append(intArray(d.getSampleRates()))
                    .append('\n');
        }

        out.append("\nPHYSICAL MICROPHONE INVENTORY\n");
        try {
            List<MicrophoneInfo> mics = audioManager.getMicrophones();
            out.append("Microphones reported by AudioManager: ").append(mics.size()).append('\n');
            for (int i = 0; i < mics.size(); i++) {
                out.append(describeMic("MIC " + i, mics.get(i), false));
            }
        } catch (IOException | RuntimeException e) {
            out.append("AudioManager.getMicrophones failed: ").append(e.getClass().getSimpleName()).append(": ").append(safe(e.getMessage())).append('\n');
        }

        int[][] sources = {
                {MediaRecorder.AudioSource.DEFAULT, 0},
                {MediaRecorder.AudioSource.UNPROCESSED, 1},
                {MediaRecorder.AudioSource.VOICE_RECOGNITION, 2},
                {MediaRecorder.AudioSource.CAMCORDER, 3}
        };
        String[] sourceNames = {"DEFAULT", "UNPROCESSED", "VOICE_RECOGNITION", "CAMCORDER"};

        boolean foundMultichannel = false;
        boolean foundDirectMultiMic = false;
        boolean foundProcessedMulti = false;
        int maxChannels = 0;
        Set<Integer> activePhysicalIds = new HashSet<>();

        out.append("\nCAPTURE MATRIX\n");
        for (int s = 0; s < sources.length; s++) {
            int source = sources[s][0];
            String sourceName = sourceNames[s];
            out.append("\n== ").append(sourceName).append(" ==\n");
            for (int channels : CHANNEL_COUNTS) {
                CaptureResult r = probeCapture(source, sourceName, channels);
                out.append(r.text);
                if (r.success) {
                    maxChannels = Math.max(maxChannels, r.actualChannels);
                    foundMultichannel |= r.actualChannels >= 2;
                    foundDirectMultiMic |= r.directDistinctMicChannels >= 2;
                    foundProcessedMulti |= r.actualChannels >= 2 && r.processedMappings > 0;
                    activePhysicalIds.addAll(r.activeMicIds);
                }
            }
        }

        String verdictTitle;
        String verdictDetail;
        out.append("\nSUMMARY\n");
        out.append("Maximum successful capture channels: ").append(maxChannels).append('\n');
        out.append("Distinct active microphone IDs observed: ").append(activePhysicalIds.size()).append(' ').append(activePhysicalIds).append('\n');
        out.append("Direct multi-mic mapping found: ").append(foundDirectMultiMic).append('\n');
        out.append("Processed multichannel mapping found: ").append(foundProcessedMulti).append('\n');

        if (foundDirectMultiMic) {
            verdictTitle = "PHONE ARRAY ACCESSIBLE";
            verdictDetail = "Android exposed at least two capture channels mapped DIRECTLY to distinct active microphones. That is the result we wanted; the next build can test real time-of-arrival localization.";
            out.append("Verdict: PHONE ARRAY ACCESSIBLE - direct independent microphone channels were exposed.\n");
        } else if (foundMultichannel) {
            verdictTitle = "MULTICHANNEL, BUT PROCESSED";
            verdictDetail = "Android exposed multiple capture channels, but not clean direct mappings from distinct microphones. We can analyze them experimentally, but should not treat them as a calibrated physical array yet.";
            out.append("Verdict: MULTICHANNEL BUT PROCESSED - localization may be experimental only.\n");
        } else {
            verdictTitle = "HAL IS STILL MIXING";
            verdictDetail = "Every successful native capture was mono or lacked independent direct microphone mappings. The phone contains multiple microphones, but Samsung's audio HAL is combining them before a normal app can access them. An external array is then the reliable SpeechCompass-style route.";
            out.append("Verdict: HAL IS STILL MIXING - no usable independent native microphone channels found.\n");
        }

        out.append("\nInterpretation note: Android defines CHANNEL_MAPPING_DIRECT as raw audio from that microphone; CHANNEL_MAPPING_PROCESSED may contain processing and contributions from other microphones.\n");
        return new ProbeSummary(out.toString(), verdictTitle, verdictDetail);
    }

    private CaptureResult probeCapture(int source, String sourceName, int requestedChannels) {
        StringBuilder out = new StringBuilder();
        AudioRecord record = null;
        try {
            int channelIndexMask = (1 << requestedChannels) - 1;
            AudioFormat format = new AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SAMPLE_RATE)
                    .setChannelIndexMask(channelIndexMask)
                    .build();
            int bufferBytes = Math.max(32768, SAMPLE_RATE * requestedChannels * 2);
            record = new AudioRecord.Builder()
                    .setAudioSource(source)
                    .setAudioFormat(format)
                    .setBufferSizeInBytes(bufferBytes)
                    .build();

            if (record.getState() != AudioRecord.STATE_INITIALIZED) {
                out.append("  request ").append(requestedChannels).append("ch: NOT INITIALIZED\n");
                return CaptureResult.fail(out.toString());
            }

            record.startRecording();
            Thread.sleep(120);
            List<MicrophoneInfo> active = record.getActiveMicrophones();
            int actualChannels = record.getChannelCount();
            int frames = SAMPLE_RATE / 3;
            short[] data = new short[frames * Math.max(1, actualChannels)];
            int read = record.read(data, 0, data.length, AudioRecord.READ_BLOCKING);

            AudioRecordingConfiguration cfg = null;
            if (Build.VERSION.SDK_INT >= 29) {
                cfg = record.getActiveRecordingConfiguration();
            }

            int directMappings = 0;
            int processedMappings = 0;
            Map<Integer, Set<Integer>> directChannelToMicIds = new HashMap<>();
            Set<Integer> activeMicIds = new HashSet<>();
            for (MicrophoneInfo mic : active) {
                activeMicIds.add(mic.getId());
                for (Pair<Integer, Integer> mapping : mic.getChannelMapping()) {
                    if (mapping.second != null && mapping.second == MicrophoneInfo.CHANNEL_MAPPING_DIRECT) {
                        directMappings++;
                        int ch = mapping.first == null ? -1 : mapping.first;
                        directChannelToMicIds.computeIfAbsent(ch, k -> new HashSet<>()).add(mic.getId());
                    } else if (mapping.second != null && mapping.second == MicrophoneInfo.CHANNEL_MAPPING_PROCESSED) {
                        processedMappings++;
                    }
                }
            }
            int directDistinctChannels = 0;
            for (Map.Entry<Integer, Set<Integer>> e : directChannelToMicIds.entrySet()) {
                if (!e.getValue().isEmpty()) directDistinctChannels++;
            }

            out.append("  request ").append(requestedChannels).append("ch -> actual ").append(actualChannels)
                    .append("ch; read ").append(read).append(" samples; active mics ").append(active.size())
                    .append("; DIRECT mappings ").append(directMappings)
                    .append("; PROCESSED mappings ").append(processedMappings).append('\n');

            if (cfg != null) {
                AudioFormat client = cfg.getClientFormat();
                AudioFormat device = cfg.getFormat();
                out.append("    config client=").append(client.getSampleRate()).append("Hz/").append(client.getChannelCount())
                        .append("ch device=").append(device.getSampleRate()).append("Hz/").append(device.getChannelCount()).append("ch\n");
            }

            for (int i = 0; i < active.size(); i++) {
                out.append(indent(describeMic("active " + i, active.get(i), true), 4));
            }

            if (read > 0 && actualChannels > 0) {
                double[] rms = channelRms(data, read, actualChannels);
                out.append("    RMS:");
                for (int ch = 0; ch < rms.length; ch++) {
                    out.append(" CH").append(ch + 1).append('=').append(String.format(Locale.US, "%.5f", rms[ch]));
                }
                out.append('\n');

                if (actualChannels >= 2) {
                    for (int a = 0; a < actualChannels; a++) {
                        for (int b = a + 1; b < actualChannels; b++) {
                            CorrLag cl = bestCorrelationLag(data, read, actualChannels, a, b, 64);
                            out.append("    CH").append(a + 1).append("↔CH").append(b + 1)
                                    .append(" corr=").append(String.format(Locale.US, "%.3f", cl.correlation))
                                    .append(" lag=").append(cl.lagSamples).append(" samples\n");
                        }
                    }
                }
            }

            return CaptureResult.ok(out.toString(), actualChannels, directDistinctChannels, processedMappings, activeMicIds);
        } catch (SecurityException e) {
            out.append("  request ").append(requestedChannels).append("ch: SECURITY ERROR ").append(safe(e.getMessage())).append('\n');
            return CaptureResult.fail(out.toString());
        } catch (UnsupportedOperationException | IllegalArgumentException e) {
            out.append("  request ").append(requestedChannels).append("ch: UNSUPPORTED (").append(e.getClass().getSimpleName()).append(") ")
                    .append(safe(e.getMessage())).append('\n');
            return CaptureResult.fail(out.toString());
        } catch (Exception e) {
            out.append("  request ").append(requestedChannels).append("ch: FAILED ").append(e.getClass().getSimpleName()).append(": ")
                    .append(safe(e.getMessage())).append('\n');
            return CaptureResult.fail(out.toString());
        } finally {
            if (record != null) {
                try {
                    if (record.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) record.stop();
                } catch (Exception ignored) {}
                try { record.release(); } catch (Exception ignored) {}
            }
        }
    }

    private String describeMic(String prefix, MicrophoneInfo mic, boolean includeMapping) {
        StringBuilder s = new StringBuilder();
        s.append(prefix).append(": id=").append(mic.getId())
                .append(" desc=").append(safe(mic.getDescription()))
                .append(" type=").append(deviceTypeName(mic.getType()))
                .append(" address=").append(safe(mic.getAddress()))
                .append(" location=").append(locationName(mic.getLocation()))
                .append(" group=").append(mic.getGroup())
                .append(" index=").append(mic.getIndexInTheGroup())
                .append(" directionality=").append(directionalityName(mic.getDirectionality()))
                .append('\n');
        MicrophoneInfo.Coordinate3F p = mic.getPosition();
        MicrophoneInfo.Coordinate3F o = mic.getOrientation();
        s.append("  position(m)=").append(coord(p)).append(" orientation=").append(coord(o))
                .append(" sensitivity=").append(floatValue(mic.getSensitivity()))
                .append(" minSPL=").append(floatValue(mic.getMinSpl()))
                .append(" maxSPL=").append(floatValue(mic.getMaxSpl())).append('\n');
        if (includeMapping) {
            s.append("  mapping=");
            List<Pair<Integer, Integer>> mappings = mic.getChannelMapping();
            if (mappings.isEmpty()) {
                s.append("none");
            } else {
                for (int i = 0; i < mappings.size(); i++) {
                    Pair<Integer, Integer> m = mappings.get(i);
                    if (i > 0) s.append(", ");
                    s.append("CH").append((m.first == null ? -1 : m.first) + 1).append(':')
                            .append(mappingName(m.second == null ? -1 : m.second));
                }
            }
            s.append('\n');
        }
        return s.toString();
    }

    private double[] channelRms(short[] data, int read, int channels) {
        double[] sums = new double[channels];
        int[] counts = new int[channels];
        for (int i = 0; i < read; i++) {
            int ch = i % channels;
            double v = data[i] / 32768.0;
            sums[ch] += v * v;
            counts[ch]++;
        }
        double[] rms = new double[channels];
        for (int ch = 0; ch < channels; ch++) {
            rms[ch] = counts[ch] == 0 ? 0.0 : Math.sqrt(sums[ch] / counts[ch]);
        }
        return rms;
    }

    private CorrLag bestCorrelationLag(short[] interleaved, int read, int channels, int channelA, int channelB, int maxLag) {
        int frames = read / channels;
        if (frames < 64) return new CorrLag(0.0, 0);
        int stride = Math.max(1, frames / 6000);
        double best = -2.0;
        int bestLag = 0;
        for (int lag = -maxLag; lag <= maxLag; lag++) {
            double sumXY = 0, sumX2 = 0, sumY2 = 0;
            int n = 0;
            int start = Math.max(0, -lag);
            int end = Math.min(frames, frames - lag);
            for (int f = start; f < end; f += stride) {
                double x = interleaved[f * channels + channelA];
                double y = interleaved[(f + lag) * channels + channelB];
                sumXY += x * y;
                sumX2 += x * x;
                sumY2 += y * y;
                n++;
            }
            if (n > 0 && sumX2 > 0 && sumY2 > 0) {
                double corr = sumXY / Math.sqrt(sumX2 * sumY2);
                if (Math.abs(corr) > Math.abs(best == -2.0 ? 0.0 : best)) {
                    best = corr;
                    bestLag = lag;
                }
            }
        }
        if (best == -2.0) best = 0.0;
        return new CorrLag(best, bestLag);
    }

    private void copyReport() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("EchoHalo Spatial Probe", lastReport));
        statusView.setText("Report copied.");
    }

    private void shareReport() {
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_SUBJECT, "EchoHalo Spatial Probe v0.1.0");
        send.putExtra(Intent.EXTRA_TEXT, lastReport);
        startActivity(Intent.createChooser(send, "Share spatial probe report"));
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView cardText(String value, int sp, int color) {
        TextView t = text(value, sp, color, true);
        t.setPadding(dp(16), dp(16), dp(16), dp(16));
        t.setBackground(makeCardBackground(0xFF080808, 0xFF303030, 14));
        return t;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(15);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setMinHeight(dp(50));
        b.setBackground(makeCardBackground(0xFF111718, 0xFF3E8E92, 14));
        return b;
    }

    private LinearLayout.LayoutParams weighted() {
        return new LinearLayout.LayoutParams(0, dp(50), 1f);
    }

    private View space(int px) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(px, 1));
        return v;
    }

    private android.graphics.drawable.Drawable makeCardBackground(int fill, int stroke, int radiusDp) {
        android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
        gd.setColor(fill);
        gd.setCornerRadius(dp(radiusDp));
        gd.setStroke(dp(1), stroke);
        return gd;
    }

    private int dp(int n) {
        return Math.round(n * getResources().getDisplayMetrics().density);
    }

    private static String safe(Object o) {
        return o == null ? "" : String.valueOf(o);
    }

    private static String intArray(int[] values) {
        if (values == null || values.length == 0) return "[]";
        StringBuilder s = new StringBuilder("[");
        for (int i = 0; i < values.length; i++) {
            if (i > 0) s.append(',');
            s.append(values[i]);
        }
        return s.append(']').toString();
    }

    private static String coord(MicrophoneInfo.Coordinate3F c) {
        if (c == null) return "unknown";
        return String.format(Locale.US, "(%.4f, %.4f, %.4f)", c.x, c.y, c.z);
    }

    private static String floatValue(float f) {
        if (Float.isNaN(f)) return "unknown";
        return String.format(Locale.US, "%.2f", f);
    }

    private static String mappingName(int mapping) {
        if (mapping == MicrophoneInfo.CHANNEL_MAPPING_DIRECT) return "DIRECT";
        if (mapping == MicrophoneInfo.CHANNEL_MAPPING_PROCESSED) return "PROCESSED";
        return "UNKNOWN(" + mapping + ")";
    }

    private static String locationName(int loc) {
        switch (loc) {
            case MicrophoneInfo.LOCATION_MAINBODY: return "MAINBODY";
            case MicrophoneInfo.LOCATION_MAINBODY_MOVABLE: return "MAINBODY_MOVABLE";
            case MicrophoneInfo.LOCATION_PERIPHERAL: return "PERIPHERAL";
            default: return "UNKNOWN(" + loc + ")";
        }
    }

    private static String directionalityName(int d) {
        switch (d) {
            case MicrophoneInfo.DIRECTIONALITY_OMNI: return "OMNI";
            case MicrophoneInfo.DIRECTIONALITY_BI_DIRECTIONAL: return "BI_DIRECTIONAL";
            case MicrophoneInfo.DIRECTIONALITY_CARDIOID: return "CARDIOID";
            case MicrophoneInfo.DIRECTIONALITY_HYPER_CARDIOID: return "HYPER_CARDIOID";
            case MicrophoneInfo.DIRECTIONALITY_SUPER_CARDIOID: return "SUPER_CARDIOID";
            default: return "UNKNOWN(" + d + ")";
        }
    }

    private static String deviceTypeName(int type) {
        switch (type) {
            case AudioDeviceInfo.TYPE_BUILTIN_MIC: return "BUILTIN_MIC";
            case AudioDeviceInfo.TYPE_BLUETOOTH_SCO: return "BLUETOOTH_SCO";
            case AudioDeviceInfo.TYPE_WIRED_HEADSET: return "WIRED_HEADSET";
            case AudioDeviceInfo.TYPE_USB_DEVICE: return "USB_DEVICE";
            case AudioDeviceInfo.TYPE_USB_HEADSET: return "USB_HEADSET";
            case AudioDeviceInfo.TYPE_TELEPHONY: return "TELEPHONY";
            default: return "TYPE_" + type;
        }
    }

    private static String indent(String value, int spaces) {
        String pad = new String(new char[spaces]).replace('\0', ' ');
        return pad + value.replace("\n", "\n" + pad);
    }

    private static final class CorrLag {
        final double correlation;
        final int lagSamples;
        CorrLag(double correlation, int lagSamples) {
            this.correlation = correlation;
            this.lagSamples = lagSamples;
        }
    }

    private static final class ProbeSummary {
        final String report;
        final String verdictTitle;
        final String verdictDetail;
        ProbeSummary(String report, String verdictTitle, String verdictDetail) {
            this.report = report;
            this.verdictTitle = verdictTitle;
            this.verdictDetail = verdictDetail;
        }
    }

    private static final class CaptureResult {
        final boolean success;
        final String text;
        final int actualChannels;
        final int directDistinctMicChannels;
        final int processedMappings;
        final Set<Integer> activeMicIds;

        private CaptureResult(boolean success, String text, int actualChannels,
                              int directDistinctMicChannels, int processedMappings, Set<Integer> activeMicIds) {
            this.success = success;
            this.text = text;
            this.actualChannels = actualChannels;
            this.directDistinctMicChannels = directDistinctMicChannels;
            this.processedMappings = processedMappings;
            this.activeMicIds = activeMicIds;
        }

        static CaptureResult fail(String text) {
            return new CaptureResult(false, text, 0, 0, 0, new HashSet<>());
        }

        static CaptureResult ok(String text, int channels, int directChannels, int processedMappings, Set<Integer> ids) {
            return new CaptureResult(true, text, channels, directChannels, processedMappings, ids);
        }
    }
}
