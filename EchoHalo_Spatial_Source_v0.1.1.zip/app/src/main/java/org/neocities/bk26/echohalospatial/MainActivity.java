package org.neocities.bk26.echohalospatial;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.EnumMap;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity implements SpatialAudioEngine.Listener {
    private static final String VERSION = "0.4.0";
    private static final int REQ_MIC = 81;

    private SpatialAudioEngine engine;
    private TextView statusView;
    private TextView featureView;
    private TextView arrowView;
    private TextView directionView;
    private TextView confidenceView;
    private TextView detailView;
    private TextView calibrationSummary;
    private Button startButton;
    private Button liveButton;
    private final Map<SpatialAudioEngine.Direction, Button> calButtons = new EnumMap<>(SpatialAudioEngine.Direction.class);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        engine = new SpatialAudioEngine(this, this);
        buildUi();
        refreshCalibrationSummary();
    }

    @Override
    protected void onDestroy() {
        if (engine != null) engine.stop();
        super.onDestroy();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.BLACK);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(16), dp(18), dp(28));
        root.setBackgroundColor(Color.BLACK);
        scroll.addView(root);

        root.addView(text("EchoHalo Spatial Calibration Lab", 27, Color.WHITE, true));
        TextView sub = text("Two-channel directional-audio experiment · v" + VERSION, 14, 0xFF9AA0A6, false);
        sub.setPadding(0, dp(2), 0, dp(14));
        root.addView(sub);

        root.addView(card("PURPOSE\nCan Samsung's public two-channel CAMCORDER stream reliably identify where a sound is coming from? This build learns your phone's real acoustic fingerprint instead of assuming an ideal microphone array.", 15, 0xFFFFD17A));

        statusView = text("Ready. Start the microphone, then calibrate the four directions.", 14, 0xFFAAB2BA, false);
        statusView.setPadding(0, dp(14), 0, dp(8));
        root.addView(statusView);

        startButton = button("START SPATIAL MIC");
        startButton.setOnClickListener(v -> toggleMic());
        root.addView(startButton, fullButtonLp(54, 0));

        root.addView(card("CALIBRATION SETUP\nLay the Samsung flat, SCREEN UP, and do not move it. The TOP edge of the phone is FRONT. Play the supplied broadband calibration noise from a SECOND device about 3–4 ft away. Move only that speaker. Put it at the requested direction, then tap the matching button and hold it still for 4.5 seconds.", 14, 0xFFB8C0C8), fullWrapLp(12));

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        Button left = calButton(SpatialAudioEngine.Direction.LEFT, "←  CAL LEFT");
        Button front = calButton(SpatialAudioEngine.Direction.FRONT, "↑  CAL FRONT");
        row1.addView(left, weighted()); row1.addView(space(dp(8))); row1.addView(front, weighted());
        root.addView(row1, fullWrapLp(8));

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        Button right = calButton(SpatialAudioEngine.Direction.RIGHT, "CAL RIGHT  →");
        Button behind = calButton(SpatialAudioEngine.Direction.BEHIND, "CAL BEHIND  ↓");
        row2.addView(right, weighted()); row2.addView(space(dp(8))); row2.addView(behind, weighted());
        root.addView(row2, fullWrapLp(8));

        calibrationSummary = text("No calibration yet.", 12, 0xFFCDD4DB, false);
        calibrationSummary.setTypeface(Typeface.MONOSPACE);
        calibrationSummary.setPadding(dp(12), dp(12), dp(12), dp(12));
        calibrationSummary.setBackground(makeCardBackground(0xFF080808, 0xFF2B2B2B, 14));
        root.addView(calibrationSummary, fullWrapLp(10));

        liveButton = button("START LIVE DIRECTION TEST");
        liveButton.setOnClickListener(v -> toggleLive());
        root.addView(liveButton, fullButtonLp(54, 10));

        LinearLayout liveCard = new LinearLayout(this);
        liveCard.setOrientation(LinearLayout.VERTICAL);
        liveCard.setGravity(Gravity.CENTER_HORIZONTAL);
        liveCard.setPadding(dp(12), dp(12), dp(12), dp(14));
        liveCard.setBackground(makeCardBackground(0xFF050505, 0xFF2D2D2D, 18));

        arrowView = text("·", 94, 0xFF42D7FF, true);
        arrowView.setGravity(Gravity.CENTER);
        liveCard.addView(arrowView);
        directionView = text("WAITING", 23, Color.WHITE, true);
        directionView.setGravity(Gravity.CENTER);
        liveCard.addView(directionView);
        confidenceView = text("confidence —", 14, 0xFF9AA0A6, false);
        confidenceView.setGravity(Gravity.CENTER);
        liveCard.addView(confidenceView);
        detailView = text("Calibrate all four directions to begin.", 11, 0xFF7F8790, false);
        detailView.setGravity(Gravity.CENTER);
        detailView.setPadding(0, dp(8), 0, 0);
        liveCard.addView(detailView);
        root.addView(liveCard, fullWrapLp(10));

        featureView = text("Live features: —", 12, 0xFFBFC7CF, false);
        featureView.setTypeface(Typeface.MONOSPACE);
        featureView.setPadding(dp(12), dp(12), dp(12), dp(12));
        featureView.setBackground(makeCardBackground(0xFF080808, 0xFF242424, 14));
        root.addView(featureView, fullWrapLp(10));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        Button copy = button("COPY REPORT");
        copy.setOnClickListener(v -> copyReport());
        Button clear = button("CLEAR CALIBRATION");
        clear.setOnClickListener(v -> {
            engine.setLiveEnabled(false);
            engine.clearCalibration();
            arrowView.setText("·"); directionView.setText("WAITING"); confidenceView.setText("confidence —");
            detailView.setText("Calibration cleared.");
            refreshCalibrationSummary();
            updateLiveButton();
        });
        actions.addView(copy, weighted()); actions.addView(space(dp(8))); actions.addView(clear, weighted());
        root.addView(actions, fullWrapLp(10));

        Button echo = button("OPEN ECHOHALO PWA");
        echo.setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://bk26.neocities.org/EchoHalo/"))));
        root.addView(echo, fullButtonLp(50, 8));

        TextView footer = text("Experimental accessibility R&D. This build does not alter cochlear-implant programming and is not a medical device.", 11, 0xFF70777E, false);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(dp(8), dp(18), dp(8), 0);
        root.addView(footer);

        setContentView(scroll);
        updateLiveButton();
    }

    private Button calButton(SpatialAudioEngine.Direction d, String label) {
        Button b = button(label);
        b.setOnClickListener(v -> engine.beginCalibration(d));
        calButtons.put(d, b);
        return b;
    }

    private void toggleMic() {
        if (engine.isRunning()) {
            engine.stop();
            startButton.setText("START SPATIAL MIC");
            statusView.setText("Spatial microphone stopped.");
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
        } else {
            startEngine();
        }
    }

    private void startEngine() {
        engine.start();
        startButton.setText("STOP SPATIAL MIC");
        statusView.setText("Starting two-channel CAMCORDER stream…");
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_MIC && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startEngine();
        } else if (requestCode == REQ_MIC) {
            statusView.setText("Microphone permission is required for the spatial calibration lab.");
        }
    }

    private void toggleLive() {
        if (!engine.isRunning()) {
            Toast.makeText(this, "Start the spatial mic first.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!engine.hasAllProfiles()) {
            Toast.makeText(this, "Calibrate LEFT, FRONT, RIGHT and BEHIND first.", Toast.LENGTH_LONG).show();
            return;
        }
        engine.setLiveEnabled(!engine.isLiveEnabled());
        if (!engine.isLiveEnabled()) {
            arrowView.setText("·"); directionView.setText("PAUSED"); confidenceView.setText("confidence —");
        } else {
            directionView.setText("LISTENING");
        }
        updateLiveButton();
    }

    private void updateLiveButton() {
        if (liveButton == null) return;
        liveButton.setText(engine.isLiveEnabled() ? "STOP LIVE DIRECTION TEST" : "START LIVE DIRECTION TEST");
        liveButton.setEnabled(engine.hasAllProfiles());
    }

    @Override
    public void onEngineStatus(String text, boolean error) {
        statusView.setText(text);
        statusView.setTextColor(error ? 0xFFFF7C7C : 0xFFAAB2BA);
        startButton.setText(engine.isRunning() ? "STOP SPATIAL MIC" : "START SPATIAL MIC");
        if (error) for (Button b : calButtons.values()) b.setEnabled(true);
    }

    @Override
    public void onFeature(SpatialAudioEngine.Feature f) {
        featureView.setText("Live features\n" + f.reportLine());
    }

    @Override
    public void onCalibrationProgress(SpatialAudioEngine.Direction d, long millisRemaining, int acceptedFrames) {
        double sec = millisRemaining / 1000.0;
        statusView.setText(String.format(Locale.US, "CALIBRATING %s · %.1f s · %d usable frames", d.label, sec, acceptedFrames));
        for (Button b : calButtons.values()) b.setEnabled(false);
    }

    @Override
    public void onCalibrationComplete(SpatialAudioEngine.Direction d, SpatialAudioEngine.CalibrationProfile p) {
        statusView.setText("Captured " + d.label + " · " + p.frames + " usable frames. Move the external speaker to the next position.");
        for (Button b : calButtons.values()) b.setEnabled(true);
        refreshCalibrationSummary();
        updateLiveButton();
    }

    @Override
    public void onClassification(SpatialAudioEngine.Direction d, double confidence, SpatialAudioEngine.Feature f, String detail) {
        if (!engine.isLiveEnabled()) return;
        if (d == null) {
            arrowView.setText("·");
            directionView.setText("LISTENING");
            confidenceView.setText("confidence —");
            detailView.setText(detail);
            return;
        }
        arrowView.setText(d.arrow);
        directionView.setText(d.label);
        int pct = (int) Math.round(confidence * 100.0);
        confidenceView.setText("confidence " + pct + "%");
        detailView.setText(detail);
    }

    private void refreshCalibrationSummary() {
        StringBuilder b = new StringBuilder();
        b.append("CALIBRATION  ").append(engine.profileCount()).append("/4\n");
        for (SpatialAudioEngine.Direction d : SpatialAudioEngine.Direction.values()) {
            SpatialAudioEngine.CalibrationProfile p = engine.getProfile(d);
            b.append(String.format(Locale.US, "%-7s  ", d.label));
            if (p == null) b.append("—\n");
            else b.append(String.format(Locale.US, "lag=%+.1f  low=%+.1f  mid=%+.1f  high=%+.1f  corr=%.2f  n=%d\n",
                    p.center[0], p.center[1], p.center[2], p.center[3], p.center[4], p.frames));
        }
        calibrationSummary.setText(b.toString());
    }

    private void copyReport() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("EchoHalo Spatial Calibration Report", engine.buildReport()));
        Toast.makeText(this, "Spatial calibration report copied.", Toast.LENGTH_SHORT).show();
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private TextView card(String s, int sp, int color) {
        TextView t = text(s, sp, color, false);
        t.setPadding(dp(14), dp(14), dp(14), dp(14));
        t.setBackground(makeCardBackground(0xFF090909, 0xFF2A2A2A, 14));
        return t;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s); b.setTextColor(Color.WHITE); b.setTextSize(13); b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackground(makeCardBackground(0xFF15191C, 0xFF3C464D, 14));
        b.setPadding(dp(8), 0, dp(8), 0);
        return b;
    }

    private LinearLayout.LayoutParams weighted() {
        return new LinearLayout.LayoutParams(0, dp(52), 1f);
    }

    private View space(int w) {
        View v = new View(this); v.setLayoutParams(new LinearLayout.LayoutParams(w, 1)); return v;
    }

    private LinearLayout.LayoutParams fullButtonLp(int h, int top) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(h));
        lp.setMargins(0, dp(top), 0, 0); return lp;
    }

    private LinearLayout.LayoutParams fullWrapLp(int top) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(top), 0, 0); return lp;
    }

    private android.graphics.drawable.GradientDrawable makeCardBackground(int fill, int stroke, int radiusDp) {
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setColor(fill); g.setCornerRadius(dp(radiusDp)); g.setStroke(dp(1), stroke); return g;
    }

    private int dp(int x) { return (int) (x * getResources().getDisplayMetrics().density + 0.5f); }
}
