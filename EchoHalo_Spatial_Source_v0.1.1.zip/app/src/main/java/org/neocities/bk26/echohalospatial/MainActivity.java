package org.neocities.bk26.echohalospatial;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayDeque;
import java.util.EnumMap;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity implements SpatialAudioEngine.Listener {
    private static final String VERSION = "0.4.1";
    private static final int REQ_MIC = 81;

    private SpatialAudioEngine engine;
    private TextView statusView;
    private TextView featureView;
    private TextView arrowView;
    private TextView directionView;
    private TextView confidenceView;
    private TextView detailView;
    private TextView calibrationSummary;
    private TextView blindSummary;
    private TextView lastTrialView;
    private LagHistoryView lagHistoryView;
    private Button startButton;
    private Button liveButton;
    private final Map<SpatialAudioEngine.Direction, Button> calButtons = new EnumMap<>(SpatialAudioEngine.Direction.class);
    private final Map<SpatialAudioEngine.Direction, Button> truthButtons = new EnumMap<>(SpatialAudioEngine.Direction.class);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        engine = new SpatialAudioEngine(this, this);
        buildUi();
        refreshCalibrationSummary();
        refreshBlindSummary();
    }

    @Override
    protected void onDestroy() {
        if (engine != null) engine.stop();
        super.onDestroy();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.BLACK);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(16), dp(18), dp(28));
        root.setBackgroundColor(Color.BLACK);
        scroll.addView(root);

        root.addView(text("EchoHalo Spatial Calibration Lab", 27, Color.WHITE, true));
        TextView sub = text("Blind repeatability experiment · v" + VERSION, 14, 0xFF9AA0A6, false);
        sub.setPadding(0, dp(2), 0, dp(14));
        root.addView(sub);

        root.addView(card("PURPOSE\nProve whether Samsung's public two-channel CAMCORDER stream can repeatedly identify LEFT / FRONT / RIGHT / BEHIND from acoustic evidence alone. v0.4.1 keeps the learned four-way fingerprint and adds ground-truth scoring, a confusion matrix, runner-up probabilities, and live lag history.", 15, 0xFFFFD17A));

        statusView = text(engine.hasAllProfiles()
                ? "Saved 4/4 calibration found. Start the microphone to begin the blind test."
                : "Ready. Start the microphone, then calibrate the four directions.",
                14, 0xFFAAB2BA, false);
        statusView.setPadding(0, dp(14), 0, dp(8));
        root.addView(statusView);

        startButton = button("START SPATIAL MIC");
        startButton.setOnClickListener(v -> toggleMic());
        root.addView(startButton, fullButtonLp(54, 0));

        root.addView(card("CALIBRATION\nKeep the Samsung flat, SCREEN UP, and stationary. TOP=FRONT, right edge=RIGHT, bottom=BEHIND, left edge=LEFT. Use the same broadband sound from a second device about 3–4 ft away. Existing v0.4.0 calibration is retained when Android installs this as an update.", 14, 0xFFB8C0C8), fullWrapLp(12));

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        Button left = calButton(SpatialAudioEngine.Direction.LEFT, "←  CAL LEFT");
        Button front = calButton(SpatialAudioEngine.Direction.FRONT, "↑  CAL FRONT");
        row1.addView(left, weighted()); row1.addView(space(dp(8))); row1.addView(front, weighted());
        root.addView(row1, fullWrapLp(8));

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        Button right = calButton(SpatialAudioEngine.Direction.RIGHT, "CAL RIGHT  →");
        Button behind = calButton(SpatialAudioEngine.Direction.BEHIND, "CAL BEHIND  ↓");
        row2.addView(right, weighted()); row2.addView(space(dp(8))); row2.addView(behind, weighted());
        root.addView(row2, fullWrapLp(8));

        calibrationSummary = text("No calibration yet.", 12, 0xFFCDD4DB, false);
        calibrationSummary.setTypeface(Typeface.MONOSPACE);
        calibrationSummary.setPadding(dp(12), dp(12), dp(12), dp(12));
        calibrationSummary.setBackground(makeCardBackground(0xFF080808, 0xFF2B2B2B, 14));
        root.addView(calibrationSummary, fullWrapLp(10));

        liveButton = button("START LIVE DIRECTION TEST");
        liveButton.setOnClickListener(v -> toggleLive());
        root.addView(liveButton, fullButtonLp(54, 10));

        LinearLayout liveCard = new LinearLayout(this);
        liveCard.setOrientation(LinearLayout.VERTICAL);
        liveCard.setGravity(Gravity.CENTER_HORIZONTAL);
        liveCard.setPadding(dp(12), dp(12), dp(12), dp(14));
        liveCard.setBackground(makeCardBackground(0xFF050505, 0xFF2D2D2D, 18));

        arrowView = text("·", 94, 0xFF42D7FF, true);
        arrowView.setGravity(Gravity.CENTER);
        liveCard.addView(arrowView);
        directionView = text("WAITING", 23, Color.WHITE, true);
        directionView.setGravity(Gravity.CENTER);
        liveCard.addView(directionView);
        confidenceView = text("posterior — · runner-up —", 14, 0xFF9AA0A6, false);
        confidenceView.setGravity(Gravity.CENTER);
        liveCard.addView(confidenceView);
        detailView = text("Calibrate all four directions to begin.", 11, 0xFF7F8790, false);
        detailView.setGravity(Gravity.CENTER);
        detailView.setPadding(0, dp(8), 0, 0);
        liveCard.addView(detailView);
        root.addView(liveCard, fullWrapLp(10));

        TextView lagTitle = text("LIVE INTERCHANNEL LAG HISTORY  ·  accepted sound frames", 11, 0xFF9AA0A6, true);
        lagTitle.setPadding(dp(4), dp(12), 0, dp(6));
        root.addView(lagTitle);
        lagHistoryView = new LagHistoryView(this);
        lagHistoryView.setBackground(makeCardBackground(0xFF050505, 0xFF242424, 14));
        root.addView(lagHistoryView, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(170)));

        featureView = text("Live features: —", 12, 0xFFBFC7CF, false);
        featureView.setTypeface(Typeface.MONOSPACE);
        featureView.setPadding(dp(12), dp(12), dp(12), dp(12));
        featureView.setBackground(makeCardBackground(0xFF080808, 0xFF242424, 14));
        root.addView(featureView, fullWrapLp(10));

        root.addView(card("BLIND REPEATABILITY TEST\nMove the sound source to a random cardinal position without changing the phone. Wait for the large arrow to settle, then tap the ACTUAL position below. Each tap records one fresh prediction. Aim for several trials per direction in mixed order. Do not tap during silence or while moving the source.", 14, 0xFFA9E8FF), fullWrapLp(14));

        LinearLayout truthRow1 = new LinearLayout(this);
        truthRow1.setOrientation(LinearLayout.HORIZONTAL);
        truthRow1.addView(truthButton(SpatialAudioEngine.Direction.LEFT, "ACTUAL  ← LEFT"), weighted());
        truthRow1.addView(space(dp(8)));
        truthRow1.addView(truthButton(SpatialAudioEngine.Direction.FRONT, "ACTUAL  ↑ FRONT"), weighted());
        root.addView(truthRow1, fullWrapLp(8));

        LinearLayout truthRow2 = new LinearLayout(this);
        truthRow2.setOrientation(LinearLayout.HORIZONTAL);
        truthRow2.addView(truthButton(SpatialAudioEngine.Direction.RIGHT, "ACTUAL  RIGHT →"), weighted());
        truthRow2.addView(space(dp(8)));
        truthRow2.addView(truthButton(SpatialAudioEngine.Direction.BEHIND, "ACTUAL  BEHIND ↓"), weighted());
        root.addView(truthRow2, fullWrapLp(8));

        lastTrialView = text("No blind trials recorded yet.", 13, 0xFFCBD3DA, true);
        lastTrialView.setPadding(dp(12), dp(12), dp(12), dp(4));
        root.addView(lastTrialView);

        blindSummary = text("", 12, 0xFFCDD4DB, false);
        blindSummary.setTypeface(Typeface.MONOSPACE);
        blindSummary.setPadding(dp(12), dp(12), dp(12), dp(12));
        blindSummary.setBackground(makeCardBackground(0xFF080808, 0xFF2B2B2B, 14));
        root.addView(blindSummary, fullWrapLp(4));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        Button copy = button("COPY REPORT");
        copy.setOnClickListener(v -> copyReport());
        Button clearTrials = button("CLEAR TRIALS");
        clearTrials.setOnClickListener(v -> {
            engine.clearBlindTrials();
            lastTrialView.setText("Blind trial session cleared.");
            refreshBlindSummary();
        });
        actions.addView(copy, weighted()); actions.addView(space(dp(8))); actions.addView(clearTrials, weighted());
        root.addView(actions, fullWrapLp(10));

        Button clearCalibration = button("CLEAR CALIBRATION");
        clearCalibration.setOnClickListener(v -> {
            engine.setLiveEnabled(false);
            engine.clearBlindTrials();
            engine.clearCalibration();
            lagHistoryView.reset();
            arrowView.setText("·");
            directionView.setText("WAITING");
            confidenceView.setText("posterior — · runner-up —");
            detailView.setText("Calibration cleared.");
            lastTrialView.setText("Calibration and blind trial session cleared.");
            refreshCalibrationSummary();
            refreshBlindSummary();
            updateLiveControls();
        });
        root.addView(clearCalibration, fullButtonLp(50, 8));

        Button echo = button("OPEN ECHOHALO PWA");
        echo.setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://bk26.neocities.org/EchoHalo/"))));
        root.addView(echo, fullButtonLp(50, 8));

        TextView footer = text("Experimental accessibility R&D. This build measures phone audio only; it does not alter cochlear-implant programming and is not a medical device.", 11, 0xFF70777E, false);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(dp(8), dp(18), dp(8), 0);
        root.addView(footer);

        setContentView(scroll);
        updateLiveControls();
    }

    private Button calButton(SpatialAudioEngine.Direction d, String label) {
        Button b = button(label);
        b.setOnClickListener(v -> {
            boolean hadTrials = engine.getBlindTrialCount() > 0;
            engine.beginCalibration(d);
            if (hadTrials) {
                lastTrialView.setText("Blind trials cleared because calibration changed.");
                refreshBlindSummary();
            }
            updateLiveControls();
        });
        calButtons.put(d, b);
        return b;
    }

    private Button truthButton(SpatialAudioEngine.Direction d, String label) {
        Button b = button(label);
        b.setOnClickListener(v -> recordTruth(d));
        truthButtons.put(d, b);
        return b;
    }

    private void toggleMic() {
        if (engine.isRunning()) {
            engine.stop();
            startButton.setText("START SPATIAL MIC");
            statusView.setText("Spatial microphone stopped.");
            arrowView.setText("·");
            directionView.setText("STOPPED");
            confidenceView.setText("posterior — · runner-up —");
            updateLiveControls();
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
        } else {
            startEngine();
        }
    }

    private void startEngine() {
        engine.start();
        startButton.setText("STOP SPATIAL MIC");
        statusView.setText("Starting two-channel CAMCORDER stream…");
        updateLiveControls();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_MIC && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startEngine();
        } else if (requestCode == REQ_MIC) {
            statusView.setText("Microphone permission is required for the spatial calibration lab.");
        }
    }

    private void toggleLive() {
        if (!engine.isRunning()) {
            Toast.makeText(this, "Start the spatial mic first.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!engine.hasAllProfiles()) {
            Toast.makeText(this, "Calibrate LEFT, FRONT, RIGHT and BEHIND first.", Toast.LENGTH_LONG).show();
            return;
        }
        engine.setLiveEnabled(!engine.isLiveEnabled());
        if (!engine.isLiveEnabled()) {
            arrowView.setText("·");
            directionView.setText("PAUSED");
            confidenceView.setText("posterior — · runner-up —");
            detailView.setText("Live classification paused.");
        } else {
            directionView.setText("LISTENING");
            detailView.setText("Move the sound source, let the result settle, then tap its ACTUAL position below.");
        }
        updateLiveControls();
    }

    private void updateLiveControls() {
        if (liveButton != null) {
            liveButton.setText(engine.isLiveEnabled() ? "STOP LIVE DIRECTION TEST" : "START LIVE DIRECTION TEST");
            liveButton.setEnabled(engine.hasAllProfiles() && engine.isRunning());
        }
        boolean truthEnabled = engine.isLiveEnabled() && engine.hasAllProfiles() && engine.isRunning();
        for (Button b : truthButtons.values()) b.setEnabled(truthEnabled);
    }

    private void recordTruth(SpatialAudioEngine.Direction actual) {
        SpatialAudioEngine.BlindTrial t = engine.recordGroundTruth(actual);
        if (t == null) {
            Toast.makeText(this, "No fresh accepted prediction yet. Let the arrow settle on a clear sound, then tap again.", Toast.LENGTH_LONG).show();
            return;
        }
        String result = t.isCorrect() ? "✓ CORRECT" : "✕ MISS";
        lastTrialView.setText(String.format(Locale.US,
                "%s  ·  actual %s  ·  predicted %s  ·  %.0f%%  ·  runner-up %s %.0f%%",
                result, t.actual.label, t.predicted.label, t.bestPosterior * 100.0,
                t.runnerUp == null ? "—" : t.runnerUp.label, t.runnerUpPosterior * 100.0));
        lastTrialView.setTextColor(t.isCorrect() ? 0xFF9BE7B0 : 0xFFFF9B9B);
        refreshBlindSummary();
    }

    @Override
    public void onEngineStatus(String text, boolean error) {
        statusView.setText(text);
        statusView.setTextColor(error ? 0xFFFF7C7C : 0xFFAAB2BA);
        startButton.setText(engine.isRunning() ? "STOP SPATIAL MIC" : "START SPATIAL MIC");
        if (error) for (Button b : calButtons.values()) b.setEnabled(true);
        updateLiveControls();
    }

    @Override
    public void onFeature(SpatialAudioEngine.Feature f) {
        featureView.setText("Live features\n" + f.reportLine());
    }

    @Override
    public void onCalibrationProgress(SpatialAudioEngine.Direction d, long millisRemaining, int acceptedFrames) {
        double sec = millisRemaining / 1000.0;
        statusView.setText(String.format(Locale.US, "CALIBRATING %s · %.1f s · %d usable frames", d.label, sec, acceptedFrames));
        for (Button b : calButtons.values()) b.setEnabled(false);
        updateLiveControls();
    }

    @Override
    public void onCalibrationComplete(SpatialAudioEngine.Direction d, SpatialAudioEngine.CalibrationProfile p) {
        statusView.setText("Captured " + d.label + " · " + p.frames + " usable frames. Move the external speaker to the next position.");
        for (Button b : calButtons.values()) b.setEnabled(true);
        refreshCalibrationSummary();
        refreshBlindSummary();
        lagHistoryView.reset();
        updateLiveControls();
    }

    @Override
    public void onClassification(SpatialAudioEngine.ClassificationResult r) {
        if (!engine.isLiveEnabled()) return;
        if (!r.accepted || r.best == null) {
            arrowView.setText("·");
            directionView.setText("LISTENING");
            confidenceView.setText("posterior — · runner-up —");
            detailView.setText(r.detail);
            return;
        }
        arrowView.setText(r.best.arrow);
        directionView.setText(r.best.label);
        confidenceView.setText(String.format(Locale.US,
                "posterior %.0f%% · runner-up %s %.0f%% · confidence %.0f%%",
                r.bestPosterior * 100.0,
                r.runnerUp == null ? "—" : r.runnerUp.label,
                r.runnerUpPosterior * 100.0,
                r.confidence * 100.0));
        detailView.setText(r.detail);
        lagHistoryView.addLag(r.feature.lagSamples);
    }

    private void refreshCalibrationSummary() {
        StringBuilder b = new StringBuilder();
        b.append("CALIBRATION  ").append(engine.profileCount()).append("/4\n");
        for (SpatialAudioEngine.Direction d : SpatialAudioEngine.Direction.values()) {
            SpatialAudioEngine.CalibrationProfile p = engine.getProfile(d);
            b.append(String.format(Locale.US, "%-7s  ", d.label));
            if (p == null) b.append("—\n");
            else b.append(String.format(Locale.US, "lag=%+.1f  low=%+.1f  mid=%+.1f  high=%+.1f  corr=%.2f  n=%d\n",
                    p.center[0], p.center[1], p.center[2], p.center[3], p.center[4], p.frames));
        }
        calibrationSummary.setText(b.toString());
        if (lagHistoryView != null) lagHistoryView.invalidate();
    }

    private void refreshBlindSummary() {
        if (blindSummary == null) return;
        int total = engine.getBlindTrialCount();
        int correct = engine.getBlindCorrectCount();
        int[][] m = engine.getConfusionMatrixCopy();
        StringBuilder b = new StringBuilder();
        b.append("BLIND SCORE  ").append(correct).append('/').append(total);
        if (total > 0) b.append(String.format(Locale.US, "  %.1f%%", correct * 100.0 / total));
        b.append("\nrows=ACTUAL · columns=PREDICTED\n");
        b.append("          L    F    R    B\n");
        for (SpatialAudioEngine.Direction a : SpatialAudioEngine.Direction.values()) {
            b.append(String.format(Locale.US, "%-7s", a.label));
            for (SpatialAudioEngine.Direction p : SpatialAudioEngine.Direction.values()) {
                b.append(String.format(Locale.US, "%5d", m[a.ordinal()][p.ordinal()]));
            }
            int row = 0;
            for (int j = 0; j < 4; j++) row += m[a.ordinal()][j];
            if (row > 0) b.append(String.format(Locale.US, "   recall %.0f%%", m[a.ordinal()][a.ordinal()] * 100.0 / row));
            b.append('\n');
        }
        blindSummary.setText(b.toString());
    }

    private void copyReport() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("EchoHalo Spatial Blind Test Report", engine.buildReport()));
        Toast.makeText(this, "Spatial blind-test report copied.", Toast.LENGTH_SHORT).show();
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private TextView card(String s, int sp, int color) {
        TextView t = text(s, sp, color, false);
        t.setPadding(dp(14), dp(14), dp(14), dp(14));
        t.setBackground(makeCardBackground(0xFF090909, 0xFF2A2A2A, 14));
        return t;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s); b.setTextColor(Color.WHITE); b.setTextSize(13); b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackground(makeCardBackground(0xFF15191C, 0xFF3C464D, 14));
        b.setPadding(dp(8), 0, dp(8), 0);
        return b;
    }

    private LinearLayout.LayoutParams weighted() {
        return new LinearLayout.LayoutParams(0, dp(52), 1f);
    }

    private View space(int w) {
        View v = new View(this); v.setLayoutParams(new LinearLayout.LayoutParams(w, 1)); return v;
    }

    private LinearLayout.LayoutParams fullButtonLp(int h, int top) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(h));
        lp.setMargins(0, dp(top), 0, 0); return lp;
    }

    private LinearLayout.LayoutParams fullWrapLp(int top) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(top), 0, 0); return lp;
    }

    private android.graphics.drawable.GradientDrawable makeCardBackground(int fill, int stroke, int radiusDp) {
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setColor(fill); g.setCornerRadius(dp(radiusDp)); g.setStroke(dp(1), stroke); return g;
    }

    private int dp(int x) { return (int) (x * getResources().getDisplayMetrics().density + 0.5f); }

    private class LagHistoryView extends View {
        private static final int MAX_POINTS = 160;
        private final ArrayDeque<Float> points = new ArrayDeque<>();
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        LagHistoryView(Context context) {
            super(context);
            paint.setTypeface(Typeface.MONOSPACE);
        }

        void addLag(double lag) {
            points.addLast((float) Math.max(-32.0, Math.min(32.0, lag)));
            while (points.size() > MAX_POINTS) points.removeFirst();
            invalidate();
        }

        void reset() {
            points.clear();
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            if (w <= 0 || h <= 0) return;
            float left = dp(34), right = w - dp(8), top = dp(10), bottom = h - dp(20);

            paint.setStrokeWidth(dp(1));
            paint.setTextSize(dp(9));
            paint.setColor(0xFF4A5055);
            for (int lag = -32; lag <= 32; lag += 8) {
                float y = yForLag(lag, top, bottom);
                canvas.drawLine(left, y, right, y, paint);
                if (lag == -32 || lag == 0 || lag == 32) {
                    canvas.drawText(String.format(Locale.US, "%+d", lag), dp(4), y + dp(3), paint);
                }
            }

            paint.setStrokeWidth(dp(1));
            for (SpatialAudioEngine.Direction d : SpatialAudioEngine.Direction.values()) {
                SpatialAudioEngine.CalibrationProfile p = engine.getProfile(d);
                if (p == null) continue;
                float y = yForLag((float) p.center[0], top, bottom);
                paint.setColor(0xFF526A77);
                canvas.drawLine(left, y, right, y, paint);
                paint.setColor(0xFF8DA9B7);
                canvas.drawText(d.label.substring(0, 1) + String.format(Locale.US, "%+.0f", p.center[0]), left + dp(3), y - dp(2), paint);
            }

            if (points.size() > 1) {
                paint.setColor(0xFF42D7FF);
                paint.setStrokeWidth(dp(2));
                int n = points.size();
                int i = 0;
                float lastX = 0, lastY = 0;
                for (float lag : points) {
                    float x = left + (right - left) * i / Math.max(1, n - 1);
                    float y = yForLag(lag, top, bottom);
                    if (i > 0) canvas.drawLine(lastX, lastY, x, y, paint);
                    lastX = x; lastY = y; i++;
                }
                paint.setColor(Color.WHITE);
                canvas.drawCircle(lastX, lastY, dp(3), paint);
            } else {
                paint.setColor(0xFF737B82);
                paint.setTextSize(dp(10));
                canvas.drawText("Start live test to plot accepted lag", left + dp(8), (top + bottom) / 2f, paint);
            }

            paint.setColor(0xFF717980);
            paint.setTextSize(dp(9));
            canvas.drawText("oldest", left, h - dp(5), paint);
            String newest = "newest";
            canvas.drawText(newest, right - paint.measureText(newest), h - dp(5), paint);
        }

        private float yForLag(float lag, float top, float bottom) {
            float clamped = Math.max(-32f, Math.min(32f, lag));
            return bottom - ((clamped + 32f) / 64f) * (bottom - top);
        }
    }
}
