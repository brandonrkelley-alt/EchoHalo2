package org.neocities.bk26.echohalospatial;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.AudioDeviceCallback;
import android.media.AudioDeviceInfo;
import android.media.audiofx.AudioEffect;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecordingConfiguration;
import android.media.MediaRecorder;
import android.media.MicrophoneInfo;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.SystemClock;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class RouteWitnessService extends Service {
    public static final String ACTION_START = "org.neocities.bk26.echohalospatial.START_WITNESS";
    public static final String ACTION_STOP = "org.neocities.bk26.echohalospatial.STOP_WITNESS";
    public static final String ACTION_MARK_OMNI = "org.neocities.bk26.echohalospatial.MARK_OMNI";
    public static final String ACTION_MARK_FRONT = "org.neocities.bk26.echohalospatial.MARK_FRONT";
    public static final String ACTION_MARK_REAR = "org.neocities.bk26.echohalospatial.MARK_REAR";
    public static final String REPORT_FILE = "route_witness_report.txt";

    private static final String VERSION = "0.3.1";
    private static final String CHANNEL_ID = "echohalo_route_witness";
    private static final int NOTIFICATION_ID = 303;
    private static final long POLL_MS = 350L;
    private static final long HEARTBEAT_MS = 5000L;

    private AudioManager audioManager;
    private HandlerThread workerThread;
    private Handler worker;
    private boolean running = false;
    private long startElapsed = 0L;
    private long lastHeartbeat = 0L;
    private String lastSignature = "";
    private String currentMarker = "UNMARKED";
    private int eventNumber = 0;
    private File reportFile;

    private final AudioManager.AudioRecordingCallback recordingCallback =
            new AudioManager.AudioRecordingCallback() {
                @Override
                public void onRecordingConfigChanged(List<AudioRecordingConfiguration> configs) {
                    if (running && worker != null) worker.post(() -> captureSnapshot("recording-callback", true));
                }
            };

    private final AudioDeviceCallback deviceCallback = new AudioDeviceCallback() {
        @Override
        public void onAudioDevicesAdded(AudioDeviceInfo[] addedDevices) {
            if (running && worker != null) worker.post(() -> {
                append("\nDEVICE CALLBACK +ADDED: " + devicesShort(addedDevices) + "\n");
                captureSnapshot("device-added", true);
            });
        }

        @Override
        public void onAudioDevicesRemoved(AudioDeviceInfo[] removedDevices) {
            if (running && worker != null) worker.post(() -> {
                append("\nDEVICE CALLBACK -REMOVED: " + devicesShort(removedDevices) + "\n");
                captureSnapshot("device-removed", true);
            });
        }
    };

    private final Runnable poller = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            captureSnapshot("poll", false);
            if (worker != null) worker.postDelayed(this, POLL_MS);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        reportFile = new File(getFilesDir(), REPORT_FILE);
        workerThread = new HandlerThread("EchoHaloRouteWitness");
        workerThread.start();
        worker = new Handler(workerThread.getLooper());
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopWitness();
            return START_NOT_STICKY;
        }
        if (ACTION_MARK_OMNI.equals(action)) {
            mark("OMNI");
            return START_NOT_STICKY;
        }
        if (ACTION_MARK_FRONT.equals(action)) {
            mark("FRONT");
            return START_NOT_STICKY;
        }
        if (ACTION_MARK_REAR.equals(action)) {
            mark("REAR");
            return START_NOT_STICKY;
        }
        startWitness();
        return START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        cleanupCallbacks();
        if (workerThread != null) workerThread.quitSafely();
        super.onDestroy();
    }

    private void startWitness() {
        if (running) {
            startForeground(NOTIFICATION_ID, buildNotification());
            append("\nSTART requested again while already running.\n");
            return;
        }
        running = true;
        startElapsed = SystemClock.elapsedRealtime();
        lastHeartbeat = 0L;
        lastSignature = "";
        currentMarker = "UNMARKED";
        eventNumber = 0;

        writeNewReport(header());
        startForeground(NOTIFICATION_ID, buildNotification());
        try {
            audioManager.registerAudioRecordingCallback(recordingCallback, worker);
        } catch (Exception e) {
            append("AudioRecordingCallback registration failed: " + error(e) + "\n");
        }
        try {
            audioManager.registerAudioDeviceCallback(deviceCallback, worker);
        } catch (Exception e) {
            append("AudioDeviceCallback registration failed: " + error(e) + "\n");
        }
        worker.post(() -> {
            appendBaseline();
            captureSnapshot("witness-start", true);
            worker.postDelayed(poller, POLL_MS);
        });
    }

    private void stopWitness() {
        if (!running) {
            stopSelf();
            return;
        }
        running = false;
        if (worker != null) {
            worker.removeCallbacks(poller);
            worker.post(() -> {
                captureSnapshot("witness-stop", true);
                append("\nEND ROUTE WITNESS\nElapsed: " + elapsedText() + "\n");
                append("Interpretation: compare the events following MARK OMNI, MARK FRONT, and MARK REAR. " +
                        "Changes in audio device, hardware format, effective source, effects, audio mode, or input-device inventory are the useful breadcrumbs.\n");
                cleanupCallbacks();
                stopForeground(STOP_FOREGROUND_REMOVE);
                stopSelf();
            });
        } else {
            cleanupCallbacks();
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
        }
    }

    private void mark(String marker) {
        if (!running) return;
        currentMarker = marker;
        if (worker != null) worker.post(() -> {
            append("\n============================================================\n");
            append("MARK " + marker + " @ " + elapsedText() + "\n");
            append("============================================================\n");
            captureSnapshot("marker-" + marker.toLowerCase(Locale.US), true);
        });
        updateNotification();
    }

    private void cleanupCallbacks() {
        try { if (audioManager != null) audioManager.unregisterAudioRecordingCallback(recordingCallback); } catch (Exception ignored) {}
        try { if (audioManager != null) audioManager.unregisterAudioDeviceCallback(deviceCallback); } catch (Exception ignored) {}
    }

    private String header() {
        String timestamp = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ", Locale.US).format(new Date());
        StringBuilder out = new StringBuilder();
        out.append("EchoHalo Route Witness v").append(VERSION).append('\n');
        out.append("Time: ").append(timestamp).append('\n');
        out.append("Device: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append('\n');
        out.append("Android: ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n");
        out.append("Fingerprint: ").append(Build.FINGERPRINT).append("\n\n");
        out.append("PURPOSE\nObserve public Android audio-routing metadata while Samsung Camera Pro Video uses OMNI, FRONT, and REAR microphone modes.\n");
        out.append("EchoHalo does NOT open an AudioRecord and does NOT capture Camera audio in this witness mode.\n");
        out.append("Android may anonymize or suppress details belonging to another app, so unchanged metadata does not prove Samsung's internal route is unchanged.\n\n");
        return out.toString();
    }

    private void appendBaseline() {
        StringBuilder out = new StringBuilder();
        out.append("BASELINE INPUT DEVICES\n");
        AudioDeviceInfo[] inputs = audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS);
        for (AudioDeviceInfo d : inputs) out.append("  ").append(describeDevice(d)).append('\n');
        out.append("\nBASELINE PUBLIC MICROPHONES\n");
        try {
            List<MicrophoneInfo> mics = audioManager.getMicrophones();
            for (MicrophoneInfo m : mics) out.append("  ").append(describeMic(m)).append('\n');
        } catch (Exception e) {
            out.append("  getMicrophones failed: ").append(error(e)).append('\n');
        }
        out.append("\nTEST ORDER: MARK OMNI → record 3–5 sec → MARK FRONT → record → MARK REAR → record.\n");
        append(out.toString());
    }

    private void captureSnapshot(String reason, boolean force) {
        if (!running && !"witness-stop".equals(reason)) return;
        Snapshot s = buildSnapshot();
        long now = SystemClock.elapsedRealtime();
        boolean heartbeat = now - lastHeartbeat >= HEARTBEAT_MS;
        if (!force && !heartbeat && s.signature.equals(lastSignature)) return;
        lastSignature = s.signature;
        if (heartbeat) lastHeartbeat = now;
        eventNumber++;
        StringBuilder out = new StringBuilder();
        out.append("\nEVENT #").append(eventNumber)
                .append(" @ ").append(elapsedText())
                .append(" marker=").append(currentMarker)
                .append(" reason=").append(reason)
                .append(heartbeat && !force ? " heartbeat" : "")
                .append('\n');
        out.append(s.text);
        append(out.toString());
    }

    private Snapshot buildSnapshot() {
        StringBuilder out = new StringBuilder();
        StringBuilder sig = new StringBuilder();

        int mode = audioManager.getMode();
        out.append("  audioMode=").append(modeName(mode)).append('(').append(mode).append(')');
        sig.append("mode=").append(mode);

        if (Build.VERSION.SDK_INT >= 31) {
            AudioDeviceInfo comm = null;
            try { comm = audioManager.getCommunicationDevice(); } catch (Exception ignored) {}
            out.append(" communicationDevice=").append(comm == null ? "<none>" : deviceKey(comm));
            sig.append("|comm=").append(comm == null ? "none" : deviceKey(comm));
        }
        out.append(" micMute=").append(audioManager.isMicrophoneMute()).append('\n');

        AudioDeviceInfo[] inputs = audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS);
        out.append("  inputDevices=").append(inputs.length).append('\n');
        for (AudioDeviceInfo d : inputs) {
            out.append("    ").append(describeDevice(d)).append('\n');
            sig.append("|dev=").append(deviceKey(d));
        }

        List<AudioRecordingConfiguration> configs;
        try {
            configs = audioManager.getActiveRecordingConfigurations();
        } catch (Exception e) {
            configs = new ArrayList<>();
            out.append("  activeRecordingConfigurations ERROR: ").append(error(e)).append('\n');
        }
        out.append("  activeRecordingConfigurations=").append(configs.size()).append('\n');
        sig.append("|cfgCount=").append(configs.size());
        for (int i = 0; i < configs.size(); i++) {
            AudioRecordingConfiguration c = configs.get(i);
            AudioDeviceInfo d = null;
            try { d = c.getAudioDevice(); } catch (Exception ignored) {}
            AudioFormat clientFormat = c.getClientFormat();
            AudioFormat hwFormat = c.getFormat();
            int clientSource = c.getClientAudioSource();
            int effectiveSource = Build.VERSION.SDK_INT >= 29 ? c.getAudioSource() : clientSource;
            out.append("    CFG ").append(i)
                    .append(" clientSource=").append(sourceName(clientSource)).append('(').append(clientSource).append(')')
                    .append(" effectiveSource=").append(sourceName(effectiveSource)).append('(').append(effectiveSource).append(')')
                    .append(" session=").append(c.getClientAudioSessionId());
            if (Build.VERSION.SDK_INT >= 29) out.append(" silenced=").append(c.isClientSilenced());
            out.append('\n');
            out.append("      device=").append(d == null ? "<hidden/null>" : describeDevice(d)).append('\n');
            out.append("      clientFormat=").append(formatText(clientFormat)).append('\n');
            out.append("      hardwareFormat=").append(formatText(hwFormat)).append('\n');
            if (Build.VERSION.SDK_INT >= 29) {
                out.append("      effects=").append(effectsText(c.getEffects())).append('\n');
                out.append("      clientEffects=").append(effectsText(c.getClientEffects())).append('\n');
            }
            sig.append("|cfg=").append(clientSource).append('/').append(effectiveSource)
                    .append('/').append(d == null ? "none" : deviceKey(d))
                    .append('/').append(formatKey(clientFormat)).append('/').append(formatKey(hwFormat));
            if (Build.VERSION.SDK_INT >= 29) sig.append('/').append(effectsText(c.getEffects()));
        }

        out.append("  publicMicrophones=");
        try {
            List<MicrophoneInfo> mics = audioManager.getMicrophones();
            out.append(mics.size()).append('\n');
            for (MicrophoneInfo m : mics) {
                out.append("    ").append(describeMic(m)).append('\n');
                sig.append("|mic=").append(m.getId()).append('/').append(m.getAddress()).append('/').append(m.getType());
            }
        } catch (Exception e) {
            out.append("ERROR ").append(error(e)).append('\n');
        }

        String[] keys = {"mic_mode", "recording_mode", "camera_direction", "input_source", "audio_source", "mic_index", "mic_num", "dual_mic", "triple_mic"};
        List<String> visibleParams = new ArrayList<>();
        for (String key : keys) {
            try {
                String v = audioManager.getParameters(key);
                if (v != null && !v.trim().isEmpty()) visibleParams.add(key + "=" + v.trim());
            } catch (Exception ignored) {}
        }
        out.append("  visibleHalParams=").append(visibleParams.isEmpty() ? "<none>" : visibleParams.toString()).append('\n');
        sig.append("|params=").append(visibleParams.toString());

        return new Snapshot(out.toString(), sig.toString());
    }

    private String describeDevice(AudioDeviceInfo d) {
        return "id=" + d.getId() +
                " type=" + deviceTypeName(d.getType()) +
                " address=" + safe(d.getAddress()) +
                " product=" + safe(d.getProductName()) +
                " channels=" + intArray(d.getChannelCounts()) +
                " rates=" + intArray(d.getSampleRates());
    }

    private String describeMic(MicrophoneInfo m) {
        String position = "unknown";
        try {
            android.graphics.PointF xy = null;
            float z = Float.NaN;
            android.media.MicrophoneInfo.Coordinate3F p = m.getPosition();
            if (p != null && sane(p.x) && sane(p.y) && sane(p.z)) {
                position = String.format(Locale.US, "(%.4f,%.4f,%.4f)", p.x, p.y, p.z);
            }
        } catch (Throwable ignored) {}
        return "id=" + m.getId() +
                " desc=" + safe(m.getDescription()) +
                " type=" + deviceTypeName(m.getType()) +
                " address=" + safe(m.getAddress()) +
                " location=" + micLocationName(m.getLocation()) +
                " group=" + m.getGroup() +
                " index=" + m.getIndexInTheGroup() +
                " directionality=" + directionalityName(m.getDirectionality()) +
                " position=" + position;
    }

    private boolean sane(float f) {
        return !Float.isNaN(f) && !Float.isInfinite(f) && Math.abs(f) < 1000f;
    }

    private String formatText(AudioFormat f) {
        if (f == null) return "<null>";
        return f.getSampleRate() + "Hz/" + f.getChannelCount() + "ch" +
                " enc=" + f.getEncoding() +
                " posMask=0x" + Integer.toHexString(f.getChannelMask()) +
                " idxMask=0x" + Integer.toHexString(f.getChannelIndexMask());
    }

    private String formatKey(AudioFormat f) {
        if (f == null) return "null";
        return f.getSampleRate() + ":" + f.getChannelCount() + ":" + f.getEncoding() + ":" + f.getChannelMask() + ":" + f.getChannelIndexMask();
    }

    private String effectsText(List<AudioEffect.Descriptor> effects) {
        if (effects == null || effects.isEmpty()) return "[]";
        StringBuilder s = new StringBuilder("[");
        for (int i = 0; i < effects.size(); i++) {
            AudioEffect.Descriptor d = effects.get(i);
            if (i > 0) s.append("; ");
            s.append(safe(d.name)).append("/").append(safe(d.implementor))
                    .append(" type=").append(d.type).append(" uuid=").append(d.uuid);
        }
        return s.append(']').toString();
    }

    private String sourceName(int s) {
        switch (s) {
            case MediaRecorder.AudioSource.DEFAULT: return "DEFAULT";
            case MediaRecorder.AudioSource.MIC: return "MIC";
            case MediaRecorder.AudioSource.VOICE_UPLINK: return "VOICE_UPLINK";
            case MediaRecorder.AudioSource.VOICE_DOWNLINK: return "VOICE_DOWNLINK";
            case MediaRecorder.AudioSource.VOICE_CALL: return "VOICE_CALL";
            case MediaRecorder.AudioSource.CAMCORDER: return "CAMCORDER";
            case MediaRecorder.AudioSource.VOICE_RECOGNITION: return "VOICE_RECOGNITION";
            case MediaRecorder.AudioSource.VOICE_COMMUNICATION: return "VOICE_COMMUNICATION";
            case MediaRecorder.AudioSource.UNPROCESSED: return "UNPROCESSED";
            case MediaRecorder.AudioSource.VOICE_PERFORMANCE: return "VOICE_PERFORMANCE";
            default: return "SOURCE_" + s;
        }
    }

    private String modeName(int m) {
        switch (m) {
            case AudioManager.MODE_NORMAL: return "NORMAL";
            case AudioManager.MODE_RINGTONE: return "RINGTONE";
            case AudioManager.MODE_IN_CALL: return "IN_CALL";
            case AudioManager.MODE_IN_COMMUNICATION: return "IN_COMMUNICATION";
            default: return "MODE_" + m;
        }
    }

    private String deviceKey(AudioDeviceInfo d) {
        return d.getId() + "/" + deviceTypeName(d.getType()) + "/" + safe(d.getAddress());
    }

    private String deviceTypeName(int type) {
        switch (type) {
            case AudioDeviceInfo.TYPE_BUILTIN_MIC: return "BUILTIN_MIC";
            case AudioDeviceInfo.TYPE_TELEPHONY: return "TELEPHONY";
            case AudioDeviceInfo.TYPE_REMOTE_SUBMIX: return "REMOTE_SUBMIX";
            case AudioDeviceInfo.TYPE_WIRED_HEADSET: return "WIRED_HEADSET";
            case AudioDeviceInfo.TYPE_USB_DEVICE: return "USB_DEVICE";
            case AudioDeviceInfo.TYPE_USB_HEADSET: return "USB_HEADSET";
            case AudioDeviceInfo.TYPE_BLUETOOTH_SCO: return "BLUETOOTH_SCO";
            case AudioDeviceInfo.TYPE_BLE_HEADSET: return "BLE_HEADSET";
            default: return "TYPE_" + type;
        }
    }

    private String micLocationName(int location) {
        switch (location) {
            case MicrophoneInfo.LOCATION_MAINBODY: return "MAINBODY";
            case MicrophoneInfo.LOCATION_MAINBODY_MOVABLE: return "MAINBODY_MOVABLE";
            case MicrophoneInfo.LOCATION_PERIPHERAL: return "PERIPHERAL";
            default: return "UNKNOWN(" + location + ")";
        }
    }

    private String directionalityName(int d) {
        switch (d) {
            case MicrophoneInfo.DIRECTIONALITY_OMNI: return "OMNI";
            case MicrophoneInfo.DIRECTIONALITY_BI_DIRECTIONAL: return "BI_DIRECTIONAL";
            case MicrophoneInfo.DIRECTIONALITY_CARDIOID: return "CARDIOID";
            case MicrophoneInfo.DIRECTIONALITY_HYPER_CARDIOID: return "HYPER_CARDIOID";
            case MicrophoneInfo.DIRECTIONALITY_SUPER_CARDIOID: return "SUPER_CARDIOID";
            default: return "UNKNOWN(" + d + ")";
        }
    }

    private String devicesShort(AudioDeviceInfo[] devices) {
        if (devices == null || devices.length == 0) return "[]";
        StringBuilder s = new StringBuilder("[");
        for (int i = 0; i < devices.length; i++) {
            if (i > 0) s.append(", ");
            s.append(deviceKey(devices[i]));
        }
        return s.append(']').toString();
    }

    private String intArray(int[] a) {
        if (a == null) return "[]";
        StringBuilder s = new StringBuilder("[");
        for (int i = 0; i < a.length; i++) {
            if (i > 0) s.append(',');
            s.append(a[i]);
        }
        return s.append(']').toString();
    }

    private String safe(Object o) {
        return o == null ? "" : String.valueOf(o);
    }

    private String error(Exception e) {
        return e.getClass().getSimpleName() + ": " + safe(e.getMessage());
    }

    private String elapsedText() {
        long ms = Math.max(0L, SystemClock.elapsedRealtime() - startElapsed);
        return String.format(Locale.US, "%d.%03ds", ms / 1000L, ms % 1000L);
    }

    private synchronized void writeNewReport(String text) {
        try (FileOutputStream out = new FileOutputStream(reportFile, false)) {
            out.write(text.getBytes(StandardCharsets.UTF_8));
        } catch (Exception ignored) {}
    }

    private synchronized void append(String text) {
        try (FileOutputStream out = new FileOutputStream(reportFile, true)) {
            out.write(text.getBytes(StandardCharsets.UTF_8));
        } catch (Exception ignored) {}
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "EchoHalo Route Witness",
                    NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Keeps EchoHalo's user-started audio-route diagnostic alive while Samsung Camera is open.");
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            nm.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent content = PendingIntent.getActivity(
                this, 1, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("EchoHalo Route Witness")
                .setContentText("Watching routes · current mark: " + currentMarker)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(content)
                .addAction(notificationAction("MARK OMNI", ACTION_MARK_OMNI, 11))
                .addAction(notificationAction("MARK FRONT", ACTION_MARK_FRONT, 12))
                .addAction(notificationAction("MARK REAR", ACTION_MARK_REAR, 13));
        return b.build();
    }

    private Notification.Action notificationAction(String label, String action, int requestCode) {
        Intent i = new Intent(this, RouteWitnessService.class);
        i.setAction(action);
        PendingIntent pi = PendingIntent.getService(
                this, requestCode, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Action.Builder(android.R.drawable.ic_menu_edit, label, pi).build();
    }

    private void updateNotification() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(NOTIFICATION_ID, buildNotification());
    }

    private static class Snapshot {
        final String text;
        final String signature;
        Snapshot(String text, String signature) {
            this.text = text;
            this.signature = signature;
        }
    }
}
