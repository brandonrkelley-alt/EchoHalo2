# EchoHalo Spatial Calibration Lab v0.4.0

This source ZIP is compatible with the existing EchoHalo2 GitHub Actions workflow that expects a root file named `EchoHalo_Spatial_Source_v0.1.1.zip`.

The outer drop-in ZIP may keep that legacy filename solely so the existing workflow can find it. The Android app inside is versionName `0.4.0`, versionCode `5`, and identifies itself as **EchoHalo Spatial Calibration Lab**.

## Build
1. Replace the existing root `EchoHalo_Spatial_Source_v0.1.1.zip` in the GitHub repository with the new drop-in ZIP.
2. Commit the replacement.
3. Start a NEW workflow run on `main`. Do not use "Re-run jobs" on an older run because that rebuilds the old commit.
4. Install the resulting debug APK. The artifact filename may still contain `v0.1.1` because the old workflow hard-codes that artifact name; the installed app itself must show v0.4.0.

## Spatial calibration test
- Lay the Samsung flat, screen up, and keep it fixed.
- Phone TOP edge = FRONT; screen right = RIGHT; bottom = BEHIND; screen left = LEFT.
- Play the supplied EchoHalo spatial calibration noise from a SECOND device/speaker around 3–4 feet away.
- Start Spatial Mic.
- Place the external speaker at each direction and tap its CAL button. Hold it still for the 4.5-second capture.
- After all four positions are calibrated, tap START LIVE DIRECTION TEST and move/speak/play sounds around the phone.
- Tap COPY REPORT and send the report back for evaluation.

This is an experimental accessibility R&D build. It does not change cochlear-implant programming.
