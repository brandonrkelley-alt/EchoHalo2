# EchoHalo Route Witness v0.3.1

This source ZIP is compatible with the existing EchoHalo2 GitHub Actions build workflow that expects a file named `EchoHalo_Spatial_Source_v0.1.1.zip`.

The outer filename can remain `v0.1.1` solely for the existing workflow. The Android app inside is versionName `0.3.1`, versionCode `4`, and identifies itself as **EchoHalo Route Witness**.

Use a NEW workflow run on `main` after replacing the source ZIP. Do not re-run an older workflow run, because GitHub reruns the old commit.
