# EchoHalo Spatial Calibration Lab v0.4.1

This source ZIP is compatible with the existing EchoHalo2 GitHub Actions workflow that expects a root file named `EchoHalo_Spatial_Source_v0.1.1.zip`.

The outer drop-in ZIP keeps that legacy filename only so the existing workflow can find it. The Android app inside is versionName `0.4.1`, versionCode `6`, and identifies itself as **EchoHalo Spatial Calibration Lab**.

## Build
1. Replace the existing root `EchoHalo_Spatial_Source_v0.1.1.zip` in the GitHub repository with this new drop-in ZIP.
2. Commit the replacement.
3. Start a NEW workflow run on `main`. Do not use **Re-run jobs** on an older run because that rebuilds the old commit.
4. Install the resulting debug APK. The artifact filename may still contain `v0.1.1` because the old workflow hard-codes that artifact name; the installed app itself must show **v0.4.1**.

If Android accepts the APK as an in-place update, the v0.4.0 four-direction calibration is retained. If the signing key changes and Android requires an uninstall first, the calibration will be lost and must be captured again.

## Blind repeatability test
1. Lay the Samsung flat, screen up, and do not move it.
2. Phone TOP edge = FRONT; screen right = RIGHT; bottom = BEHIND; screen left = LEFT.
3. Start **SPATIAL MIC**.
4. Confirm the calibration box says **4/4**. If it does not, calibrate all four positions again with the same broadband test sound from a second device about 3–4 ft away.
5. Tap **START LIVE DIRECTION TEST**.
6. Move the external sound source to a randomly chosen LEFT / FRONT / RIGHT / BEHIND position. Keep the phone fixed.
7. Wait for the large predicted arrow to settle.
8. Tap the matching **ACTUAL** direction button. That records one trial using the newest accepted classification (it must be less than 1.5 seconds old).
9. Repeat in mixed/random order. A useful first pass is 10 trials per direction (40 total). Do not tap while moving the source or during silence.
10. Watch the confusion matrix and per-direction recall update live.
11. Tap **COPY REPORT** and send the full report back for analysis.

## What v0.4.1 records
- Best predicted direction and posterior probability
- Runner-up direction and posterior probability
- Smoothed classifier confidence
- GCC-style interchannel lag
- Low / mid / high interchannel level difference
- Peak interchannel correlation
- RMS level
- Confusion matrix (rows = ACTUAL, columns = PREDICTED)
- Overall accuracy and per-direction recall
- One detailed line per recorded trial
- Session log

## Lag history graph
The live graph plots accepted-frame lag over time from -32 to +32 samples. Horizontal labeled guides mark the currently saved calibration lag center for each direction. This is useful for seeing whether the signal moves continuously between positions or snaps among stable lag states.

Recalibrating any direction automatically clears the current blind-trial session so results from two different calibration models are never mixed.

This is experimental accessibility R&D. It measures phone audio only and does not change cochlear-implant programming.
