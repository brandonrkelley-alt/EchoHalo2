# EchoHalo Spatial Probe - GitHub Cloud Build

This repository is configured to build a phone-installable Android APK entirely in GitHub Actions. Android Studio is not required on your phone or computer.

## Build from a phone

1. Open this repository on GitHub.
2. Open **Actions**.
3. Choose **Build EchoHalo Spatial Probe APK**.
4. Tap **Run workflow**, then **Run workflow** again.
5. Wait for the build to turn green (normally a few minutes).
6. Open the repository's **Releases** page and open the newest **EchoHalo Spatial Probe Build**.
7. Download `EchoHalo-Spatial-Probe-v0.1.0-debug.apk` directly to the Android phone.
8. Open the APK. Android may ask you to allow installs from your browser or Files app. Grant that permission only for the installer you are using, then install EchoHalo Spatial Probe.
9. Launch the app, allow microphone access, run the probe, and use **Share Report** or **Copy Report**.

If publishing the Release is blocked by repository policy, the APK is still saved in the successful workflow run under **Artifacts** as `EchoHalo-Spatial-Probe-v0.1.0` (GitHub downloads artifacts as a ZIP; open it to get the APK).

## Build stack

- Android Gradle Plugin 8.7.3
- Gradle 8.9
- Java 17
- compileSdk / targetSdk 35
- minSdk 28

The APK is a normal Android debug build. It is automatically debug-signed by the Android build tools and is suitable for sideload testing. It is not intended for Play Store distribution.
